<?php

// Test de VOTRE Firestore existant
echo "🔥 TEST VOTRE FIRESTORE EXISTANT\n";
echo "================================\n\n";

$projectId = 'garagesimulator-17587';
$apiKey = 'AIzaSyAx2UWxLPwQMQJUSp3lp89QPubGBTcvkQQ';

echo "🔗 Test avec VOS données existantes...\n\n";

// 1. Tester l'accès à vos interventions
echo "1. Récupération de vos interventions...\n";
$url = "https://firestore.googleapis.com/v1/projects/{$projectId}/databases/(default)/documents/interventions/id_amortisseurs?key={$apiKey}";

$ch = curl_init();
curl_setopt($ch, CURLOPT_URL, $url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
curl_close($ch);

if ($httpCode === 200) {
    $data = json_decode($response, true);
    
    if (isset($data['fields'])) {
        echo "✅ SUCCÈS! Vous avez accès à vos données.\n\n";
        
        // Afficher les données
        echo "📋 Données de l'intervention 'Amortisseurs':\n";
        foreach ($data['fields'] as $key => $field) {
            if (isset($field['stringValue'])) {
                echo "   {$key}: {$field['stringValue']}\n";
            } elseif (isset($field['integerValue'])) {
                echo "   {$key}: {$field['integerValue']}\n";
            }
        }
        
        echo "\n2. Lister toutes vos interventions...\n";
        $listUrl = "https://firestore.googleapis.com/v1/projects/{$projectId}/databases/(default)/documents/interventions?key={$apiKey}";
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $listUrl);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        $data = json_decode($response, true);
        curl_close($ch);
        
        if (isset($data['documents'])) {
            echo "✅ " . count($data['documents']) . " interventions trouvées:\n";
            foreach ($data['documents'] as $doc) {
                $id = explode('/', $doc['name']);
                $id = end($id);
                echo "   - {$id}\n";
            }
        }
        
        echo "\n🎉 VOTRE LARAVEL EST MAINTENANT CONNECTÉ À VOTRE FIRESTORE!\n";
        echo "=========================================================\n";
        echo "Collections disponibles:\n";
        echo "  - interventions (vos 8 types de réparation)\n";
        echo "  - users\n";
        echo "  - pannes\n";
        
        echo "\n👉 Utilisez le service FirestoreService.php pour:\n";
        echo "   - Mobile app: Ajouter des pannes (addPanic)\n";
        echo "   - Jeu Godot: Récupérer pannes en attente (getWaitingPannes)\n";
        echo "   - Dashboard web: Statistiques (getStatistics)\n";
        
    } else {
        echo "❌ Structure de données inattendue\n";
    }
    
} else {
    echo "❌ Échec HTTP {$httpCode}\n";
    echo "Vérifiez votre API Key ou les règles de sécurité Firestore.\n";
}