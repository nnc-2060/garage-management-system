<template>
    <Link href="/">
        <img src="/logo.png" alt="Garage Simulation" class="h-12 w-auto" />
        <!-- ou juste du texte -->
        <!-- <span class="text-2xl font-bold text-indigo-600">Garage Sim</span> -->
    </Link>
</template>