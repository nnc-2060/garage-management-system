<?php
// backend-laravel/app/Http/Controllers/Api/FirebaseController.php

namespace App\Http\Controllers\Api;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use App\Services\FirebaseService;

class FirebaseController extends Controller
{
    protected $firebaseService;

    public function __construct(FirebaseService $firebaseService)
    {
        $this->firebaseService = $firebaseService;
    }

    /**
     * Test de connexion Firebase
     */
    // backend-laravel/app/Http/Controllers/Api/FirebaseController.php

    public function testConnection(): JsonResponse
    {
        try {
            $result = $this->firebaseService->testConnection();
            
            // Récupérer TOUTES les interventions (pas juste une)
            $allInterventions = $this->firebaseService->getInterventions();
            
            // Récupérer les pannes en attente
            $waitingPannes = $this->firebaseService->getWaitingPannes();
            
            // Récupérer les utilisateurs
            $users = $this->firebaseService->getUsers();
            
            // Récupérer les statistiques
            $statistics = $this->firebaseService->getStatistics();
            
            return response()->json([
                'success' => true,
                'connected' => $result['success'] ?? false,
                'message' => $result['message'] ?? '✅ Connecté à Firebase',
                'project' => $result['project'] ?? 'garagesimulator-17587',
                'test_document' => $result['document'] ?? null, // Juste pour le test
                'all_data' => [
                    'interventions_count' => count($allInterventions),
                    'interventions' => $allInterventions,
                    'waiting_pannes_count' => count($waitingPannes),
                    'waiting_pannes' => $waitingPannes,
                    'users_count' => count($users),
                    'users' => $users,
                    'statistics' => $statistics
                ],
                'timestamp' => now()->format('Y-m-d H:i:s')
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Statistiques globales du garage
     */
    public function getStatistics(): JsonResponse
    {
        try {
            $stats = $this->firebaseService->getStatistics();
            
            return response()->json([
                'success' => true,
                'data' => [
                    'total_pannes' => $stats['total_pannes'] ?? 0,
                    'pannes_waiting' => $stats['pannes_waiting'] ?? 0,
                    'pannes_in_repair' => $stats['pannes_in_repair'] ?? 0,
                    'pannes_completed' => $stats['pannes_completed'] ?? 0,
                    'total_revenue' => $stats['total_revenue'] ?? 0,
                    'occupied_slots' => $stats['occupied_slots'] ?? 0,
                    'total_users' => $stats['total_users'] ?? 0,
                    'available_interventions' => $stats['available_interventions'] ?? 0
                ],
                'timestamp' => now()->format('Y-m-d H:i:s')
            ]);
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Récupérer les réparations actives (en cours)
     */
    public function getActiveRepairs(): JsonResponse
    {
        try {
            $url = "https://firestore.googleapis.com/v1/projects/{$this->firebaseService->projectId}/databases/(default)/documents/pannes?key={$this->firebaseService->apiKey}";
            
            $ch = curl_init();
            curl_setopt($ch, CURLOPT_URL, $url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            
            if ($httpCode === 200) {
                $data = json_decode($response, true);
                $activeRepairs = [];
                
                if (isset($data['documents'])) {
                    foreach ($data['documents'] as $doc) {
                        $fields = $this->convertFromFirestore($doc['fields']);
                        
                        // Filtrer seulement les réparations en cours
                        if (isset($fields['status']) && $fields['status'] === 'in_repair') {
                            // Récupérer les détails des interventions
                            $interventionDetails = [];
                            if (isset($fields['problems']) && is_array($fields['problems'])) {
                                $interventions = $this->firebaseService->getInterventions();
                                foreach ($fields['problems'] as $problemId) {
                                    if (isset($interventions[$problemId])) {
                                        $interventionDetails[] = $interventions[$problemId];
                                    }
                                }
                            }
                            
                            $fields['intervention_details'] = $interventionDetails;
                            $fields['firebase_id'] = $this->extractDocumentId($doc['name']);
                            $activeRepairs[] = $fields;
                        }
                    }
                }
                
                return response()->json([
                    'success' => true,
                    'data' => $activeRepairs,
                    'count' => count($activeRepairs),
                    'max_slots' => 2,
                    'available_slots' => 2 - count($activeRepairs)
                ]);
            }
            
            return response()->json([
                'success' => false,
                'error' => "Erreur HTTP $httpCode"
            ], 500);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Récupérer les voitures en attente
     */
    public function getWaitingCars(): JsonResponse
    {
        try {
            $waitingPannes = $this->firebaseService->getWaitingPannes();
            
            // Enrichir les données avec les détails des interventions
            $enrichedData = [];
            $interventions = $this->firebaseService->getInterventions();
            
            foreach ($waitingPannes as $panne) {
                $interventionDetails = [];
                $estimatedPrice = 0;
                
                if (isset($panne['problems']) && is_array($panne['problems'])) {
                    foreach ($panne['problems'] as $problemId) {
                        if (isset($interventions[$problemId])) {
                            $interventionDetails[] = $interventions[$problemId];
                            $estimatedPrice += $interventions[$problemId]['price'] ?? 0;
                        }
                    }
                }
                
                $panne['intervention_details'] = $interventionDetails;
                $panne['estimated_price'] = $estimatedPrice;
                $enrichedData[] = $panne;
            }
            
            return response()->json([
                'success' => true,
                'data' => $enrichedData,
                'count' => count($enrichedData)
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Récupérer les types de réparation (vos 8 interventions)
     */
    public function getRepairTypes(): JsonResponse
    {
        try {
            $interventions = $this->firebaseService->getInterventions();
            
            // Formater les données pour le frontend
            $formattedInterventions = [];
            foreach ($interventions as $id => $intervention) {
                $formattedInterventions[] = [
                    'id' => $id,
                    'name' => $intervention['name'] ?? $id,
                    'description' => $intervention['description'] ?? 'Description non disponible',
                    'price' => $intervention['price'] ?? 0,
                    'duration' => $intervention['duration'] ?? 30, // en minutes
                    'difficulty' => $intervention['difficulty'] ?? 'medium',
                    'parts_required' => $intervention['parts_required'] ?? []
                ];
            }
            
            return response()->json([
                'success' => true,
                'data' => $formattedInterventions,
                'count' => count($formattedInterventions)
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Inscription utilisateur (pour l'app mobile)
     */
    public function registerUser(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'name' => 'required|string|max:255',
                'email' => 'required|email',
                'phone' => 'nullable|string',
                'vehicle_brand' => 'nullable|string',
                'vehicle_model' => 'nullable|string'
            ]);
            
            // Générer un ID unique
            $userId = 'user_' . time() . '_' . rand(1000, 9999);
            
            $userData = [
                'id' => $userId,
                'name' => $validated['name'],
                'email' => $validated['email'],
                'phone' => $validated['phone'] ?? '',
                'vehicle_brand' => $validated['vehicle_brand'] ?? '',
                'vehicle_model' => $validated['vehicle_model'] ?? '',
                'created_at' => date('Y-m-d H:i:s'),
                'total_pannes' => 0,
                'total_spent' => 0,
                'status' => 'active'
            ];
            
            $result = $this->firebaseService->createDocument('users', $userId, $userData);
            
            return response()->json([
                'success' => $result['success'],
                'user_id' => $userId,
                'message' => $result['success'] ? 'Utilisateur enregistré avec succès' : 'Erreur lors de l\'enregistrement'
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Mettre à jour la progression d'une réparation (pour le jeu Godot)
     */
    public function updateRepairProgress(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'panic_id' => 'required|string',
                'progress' => 'required|integer|min:0|max:100',
                'intervention_id' => 'required|string'
            ]);
            
            $result = $this->firebaseService->updateRepairProgress(
                $validated['panic_id'],
                $validated['progress'],
                $validated['intervention_id']
            );
            
            return response()->json([
                'success' => $result['success'],
                'message' => $result['success'] ? 'Progression mise à jour' : $result['message'] ?? 'Erreur'
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Assigner une panne à un slot (pour le jeu Godot)
     */
    public function assignToSlot(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'panic_id' => 'required|string',
                'slot_number' => 'required|integer|min:1|max:2'
            ]);
            
            $result = $this->firebaseService->assignToSlot(
                $validated['panic_id'],
                $validated['slot_number']
            );
            
            return response()->json([
                'success' => $result['success'],
                'message' => $result['message'] ?? ($result['success'] ? 'Slot assigné' : 'Erreur'),
                'slot_assigned' => $result['success'] ? $validated['slot_number'] : null
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Ajouter une voiture (nécessite authentification)
     */
    public function addCar(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'brand' => 'required|string|max:100',
                'model' => 'required|string|max:100',
                'year' => 'required|integer|min:1900|max:' . date('Y'),
                'license_plate' => 'required|string|max:20',
                'owner_name' => 'required|string|max:255',
                'owner_email' => 'required|email',
                'owner_phone' => 'required|string',
                'problems' => 'required|array',
                'problems.*' => 'string'
            ]);
            
            // Créer d'abord l'utilisateur s'il n'existe pas
            $users = $this->firebaseService->getUsers();
            $userExists = false;
            $userId = null;
            
            foreach ($users as $id => $user) {
                if ($user['email'] === $validated['owner_email']) {
                    $userExists = true;
                    $userId = $id;
                    break;
                }
            }
            
            if (!$userExists) {
                $userId = 'user_' . time() . '_' . rand(1000, 9999);
                $userData = [
                    'id' => $userId,
                    'name' => $validated['owner_name'],
                    'email' => $validated['owner_email'],
                    'phone' => $validated['owner_phone'],
                    'created_at' => date('Y-m-d H:i:s'),
                    'total_pannes' => 0,
                    'total_spent' => 0
                ];
                
                $this->firebaseService->createDocument('users', $userId, $userData);
            }
            
            // Créer la panne
            $panicId = 'panic_' . time() . '_' . rand(100, 999);
            
            $panicData = [
                'id' => $panicId,
                'user_id' => $userId,
                'car_brand' => $validated['brand'],
                'car_model' => $validated['model'],
                'car_year' => $validated['year'],
                'license_plate' => $validated['license_plate'],
                'problems' => $validated['problems'],
                'status' => 'waiting',
                'total_price' => 0,
                'created_at' => date('Y-m-d H:i:s'),
                'assigned_slot' => null,
                'progress' => 0,
                'owner_name' => $validated['owner_name'],
                'owner_email' => $validated['owner_email'],
                'owner_phone' => $validated['owner_phone']
            ];
            
            $result = $this->firebaseService->createDocument('pannes', $panicId, $panicData);
            
            return response()->json([
                'success' => $result['success'],
                'message' => $result['success'] ? 'Voiture ajoutée avec succès' : 'Erreur',
                'panic_id' => $panicId,
                'estimated_wait_time' => '15 minutes' // À calculer selon la charge
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Traiter un paiement (nécessite authentification)
     */
    public function processPayment(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'panic_id' => 'required|string',
                'amount' => 'required|numeric|min:0',
                'payment_method' => 'required|string|in:cash,card,transfer',
                'transaction_id' => 'nullable|string'
            ]);
            
            // Ici, vous intégreriez un vrai système de paiement
            // Pour l'instant, on simule juste
            
            // Mettre à jour la panne
            $updateData = [
                'payment_status' => 'paid',
                'payment_method' => $validated['payment_method'],
                'payment_date' => date('Y-m-d H:i:s'),
                'transaction_id' => $validated['transaction_id'] ?? 'sim_' . time(),
                'status' => 'completed'
            ];
            
            $result = $this->firebaseService->updateDocument('pannes', $validated['panic_id'], $updateData);
            
            return response()->json([
                'success' => $result['success'],
                'message' => $result['success'] ? 'Paiement traité avec succès' : 'Erreur',
                'transaction_id' => $validated['transaction_id'] ?? 'sim_' . time()
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Envoyer une notification (nécessite authentification)
     */
    public function sendNotification(Request $request): JsonResponse
    {
        try {
            $validated = $request->validate([
                'to' => 'required|string', // email ou user_id
                'subject' => 'required|string|max:255',
                'message' => 'required|string',
                'type' => 'required|string|in:status_update,payment,reminder,info'
            ]);
            
            // Ici, vous intégreriez un service de notification (email, SMS, push)
            // Pour l'instant, on loggue juste
            
            \Log::info('Notification envoyée', [
                'to' => $validated['to'],
                'subject' => $validated['subject'],
                'type' => $validated['type']
            ]);
            
            return response()->json([
                'success' => true,
                'message' => 'Notification envoyée (simulée)',
                'notification_id' => 'notif_' . time()
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    /**
     * Récupérer toutes les données pour le dashboard
     */
    public function getDashboardData(): JsonResponse
    {
        try {
            $stats = $this->firebaseService->getStatistics();
            $activeRepairs = $this->getActiveRepairs()->getData(true)['data'] ?? [];
            $waitingCars = $this->getWaitingCars()->getData(true)['data'] ?? [];
            $repairTypes = $this->getRepairTypes()->getData(true)['data'] ?? [];
            
            return response()->json([
                'success' => true,
                'data' => [
                    'statistics' => [
                        'total_pannes' => $stats['total_pannes'] ?? 0,
                        'pannes_waiting' => $stats['pannes_waiting'] ?? 0,
                        'pannes_in_repair' => $stats['pannes_in_repair'] ?? 0,
                        'pannes_completed' => $stats['pannes_completed'] ?? 0,
                        'total_revenue' => $stats['total_revenue'] ?? 0,
                        'total_users' => $stats['total_users'] ?? 0,
                        'available_interventions' => $stats['available_interventions'] ?? 0
                    ],
                    'active_repairs' => $activeRepairs,
                    'waiting_cars' => $waitingCars,
                    'repair_types' => $repairTypes,
                    'garage_info' => [
                        'max_slots' => 2,
                        'available_slots' => 2 - count($activeRepairs),
                        'estimated_wait_time' => count($waitingCars) > 0 ? '30 minutes' : 'Aucune attente'
                    ]
                ],
                'timestamp' => now()->format('Y-m-d H:i:s')
            ]);
            
        } catch (\Exception $e) {
            return response()->json([
                'success' => false,
                'error' => $e->getMessage()
            ], 500);
        }
    }

    // ==================== MÉTHODES UTILITAIRES ====================

    private function convertFromFirestore($fields)
    {
        $result = [];
        
        foreach ($fields as $key => $field) {
            if (isset($field['stringValue'])) {
                $result[$key] = $field['stringValue'];
            } elseif (isset($field['integerValue'])) {
                $result[$key] = (int)$field['integerValue'];
            } elseif (isset($field['booleanValue'])) {
                $result[$key] = (bool)$field['booleanValue'];
            } elseif (isset($field['arrayValue']['values'])) {
                $array = [];
                foreach ($field['arrayValue']['values'] as $value) {
                    if (isset($value['stringValue'])) {
                        $array[] = $value['stringValue'];
                    } elseif (isset($value['integerValue'])) {
                        $array[] = (int)$value['integerValue'];
                    }
                }
                $result[$key] = $array;
            }
        }
        
        return $result;
    }

    private function extractDocumentId($path)
    {
        $parts = explode('/', $path);
        return end($parts);
    }
}