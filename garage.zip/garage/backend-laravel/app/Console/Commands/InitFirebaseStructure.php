<?php

namespace App\Console\Commands;

use Illuminate\Console\Command;
use App\Services\FirebaseService;

class InitFirebaseStructure extends Command
{
    protected $signature = 'firebase:init';
    protected $description = 'Initialize Firebase structure for garage simulator';

    protected $firebase;

    public function __construct(FirebaseService $firebase)
    {
        parent::__construct();
        $this->firebase = $firebase;
    }

    public function handle()
    {
        $this->info('Initializing Firebase structure...');

        // Initialize repair slots
        $this->firebase->database->getReference('repair_slots')->set([
            'slot_1' => [
                'name' => 'Slot 1',
                'occupied' => false,
                'car_id' => null,
                'mechanic_id' => null,
                'status' => 'available'
            ],
            'slot_2' => [
                'name' => 'Slot 2',
                'occupied' => false,
                'car_id' => null,
                'mechanic_id' => null,
                'status' => 'available'
            ]
        ]);

        $this->info('✅ Repair slots initialized (2 slots available)');

        // Initialize repair types
        $repairTypes = [
            'brake' => [
                'name' => 'Brake System Repair',
                'description' => 'Brake pads and discs replacement',
                'base_price' => 80,
                'base_duration' => 600,
                'category' => 'safety'
            ],
            'oil_change' => [
                'name' => 'Oil Change Service',
                'description' => 'Engine oil and filter change',
                'base_price' => 50,
                'base_duration' => 300,
                'category' => 'maintenance'
            ],
            'tire' => [
                'name' => 'Tire Replacement',
                'description' => 'Tire change and alignment',
                'base_price' => 40,
                'base_duration' => 900,
                'category' => 'safety'
            ],
            'filter' => [
                'name' => 'Air Filter Replacement',
                'description' => 'Engine air filter change',
                'base_price' => 30,
                'base_duration' => 300,
                'category' => 'maintenance'
            ],
            'battery' => [
                'name' => 'Battery Replacement',
                'description' => 'Car battery replacement',
                'base_price' => 100,
                'base_duration' => 600,
                'category' => 'electrical'
            ],
            'suspension' => [
                'name' => 'Suspension Repair',
                'description' => 'Shock absorbers replacement',
                'base_price' => 150,
                'base_duration' => 1800,
                'category' => 'safety'
            ],
            'clutch' => [
                'name' => 'Clutch System Repair',
                'description' => 'Clutch plate and bearing replacement',
                'base_price' => 200,
                'base_duration' => 2400,
                'category' => 'transmission'
            ],
            'cooling' => [
                'name' => 'Cooling System Repair',
                'description' => 'Radiator and coolant service',
                'base_price' => 90,
                'base_duration' => 1200,
                'category' => 'engine'
            ]
        ];

        foreach ($repairTypes as $type => $data) {
            $this->firebase->database->getReference('repair_types/' . $type)->set($data);
        }

        $this->info('✅ 8 repair types initialized');

        // Initialize admin user
        try {
            $adminEmail = 'admin@garage.com';
            
            // Check if admin exists
            try {
                $existingUser = $this->firebase->auth->getUserByEmail($adminEmail);
                $this->info('⚠️  Admin user already exists');
            } catch (\Exception $e) {
                // Create admin user
                $this->firebase->createUser($adminEmail, 'admin123', [
                    'name' => 'Garage Administrator',
                    'role' => 'admin',
                    'phone' => '+1234567890'
                ]);
                $this->info('✅ Admin user created: ' . $adminEmail . ' / admin123');
            }

        } catch (\Exception $e) {
            $this->error('Error creating admin user: ' . $e->getMessage());
        }

        $this->info('');
        $this->info('🎉 Firebase structure initialized successfully!');
        $this->info('Project ID: garagesimulator-17587');
        $this->info('Database URL: https://garagesimulator-17587-default-rtdb.firebaseio.com');
    }
}