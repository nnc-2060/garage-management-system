<?php

namespace App\Services;

class FirebaseService
{
    private $projectId = 'garagesimulator-17587';
    private $apiKey = 'AIzaSyAx2UWxLPwQMQJUSp3lp89QPubGBTcvkQQ';
    
    /**
     * URL de base Firestore REST API
     */
    private function getBaseUrl()
    {
        return "https://firestore.googleapis.com/v1/projects/{$this->projectId}/databases/(default)/documents";
    }
    
    /**
     * Test de connexion à VOTRE Firestore existant
     */
    public function testConnection()
    {
        // Test avec votre collection existante 'interventions'
        $url = $this->getBaseUrl() . "/interventions/id_amortisseurs?key=" . $this->apiKey;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            return [
                'success' => true,
                'message' => '✅ Connecté à votre Firestore existant!',
                'project' => $this->projectId,
                'document' => isset($data['fields']) ? $this->convertFromFirestore($data['fields']) : null
            ];
        }
        
        return [
            'success' => false,
            'message' => "❌ Erreur HTTP $httpCode - Vérifiez l'API Key",
            'response' => $response
        ];
    }
    
    /**
     * Récupérer toutes les interventions (vos 8 types de réparation)
     */
    public function getInterventions()
    {
        $url = $this->getBaseUrl() . "/interventions?key=" . $this->apiKey;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            $interventions = [];
            
            if (isset($data['documents'])) {
                foreach ($data['documents'] as $doc) {
                    $id = $this->extractDocumentId($doc['name']);
                    $fields = $this->convertFromFirestore($doc['fields']);
                    $interventions[$id] = $fields;
                }
            }
            
            return $interventions;
        }
        
        return [];
    }
    
    /**
     * Récupérer les utilisateurs
     */
    public function getUsers()
    {
        $url = $this->getBaseUrl() . "/users?key=" . $this->apiKey;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            $users = [];
            
            if (isset($data['documents'])) {
                foreach ($data['documents'] as $doc) {
                    $id = $this->extractDocumentId($doc['name']);
                    $fields = $this->convertFromFirestore($doc['fields']);
                    $users[$id] = $fields;
                }
            }
            
            return $users;
        }
        
        return [];
    }
    
    /**
     * Ajouter une nouvelle panne (pour l'app mobile)
     */
    public function addPanic($userId, $carData, $problems)
    {
        $panicId = 'panic_' . time() . '_' . rand(100, 999);
        
        $panicData = [
            'id' => $panicId,
            'user_id' => $userId,
            'car_brand' => $carData['brand'],
            'car_model' => $carData['model'],
            'car_year' => $carData['year'],
            'license_plate' => $carData['license_plate'],
            'problems' => $problems, // Liste des IDs d'interventions
            'status' => 'waiting', // waiting, in_repair, completed
            'total_price' => 0,
            'created_at' => date('Y-m-d H:i:s'),
            'assigned_slot' => null,
            'progress' => 0
        ];
        
        return $this->createDocument('pannes', $panicId, $panicData);
    }
    
    /**
     * Récupérer les pannes en attente (pour le jeu Godot)
     */
    public function getWaitingPannes()
    {
        // Pour simplifier, on récupère tout et on filtre
        $url = $this->getBaseUrl() . "/pannes?key=" . $this->apiKey;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            $waitingPannes = [];
            
            if (isset($data['documents'])) {
                foreach ($data['documents'] as $doc) {
                    $fields = $this->convertFromFirestore($doc['fields']);
                    if (isset($fields['status']) && $fields['status'] === 'waiting') {
                        $waitingPannes[] = $fields;
                    }
                }
            }
            
            return $waitingPannes;
        }
        
        return [];
    }
    
    /**
     * Assigner une panne à un slot (max 2 slots)
     */
    public function assignToSlot($panicId, $slotNumber)
    {
        // Vérifier combien de slots sont occupés
        $url = $this->getBaseUrl() . "/pannes?key=" . $this->apiKey;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            $occupiedSlots = 0;
            
            if (isset($data['documents'])) {
                foreach ($data['documents'] as $doc) {
                    $fields = $this->convertFromFirestore($doc['fields']);
                    if (isset($fields['status']) && $fields['status'] === 'in_repair' && 
                        isset($fields['assigned_slot'])) {
                        $occupiedSlots++;
                    }
                }
            }
            
            // Max 2 voitures en réparation
            if ($occupiedSlots >= 2) {
                return [
                    'success' => false,
                    'message' => 'Tous les slots sont occupés (max 2)'
                ];
            }
            
            // Mettre à jour la panne
            $updateData = [
                'status' => 'in_repair',
                'assigned_slot' => $slotNumber,
                'repair_started_at' => date('Y-m-d H:i:s')
            ];
            
            return $this->updateDocument('pannes', $panicId, $updateData);
        }
        
        return ['success' => false, 'message' => 'Erreur de connexion'];
    }
    
    /**
     * Mettre à jour la progression d'une réparation (jeu Godot)
     */
    public function updateRepairProgress($panicId, $progress, $interventionId)
    {
        $panic = $this->getDocument('pannes', $panicId);
        
        if (!$panic) {
            return ['success' => false, 'message' => 'Panne non trouvée'];
        }
        
        // Calculer le prix total basé sur les interventions
        $interventions = $this->getInterventions();
        $totalPrice = 0;
        
        if (isset($panic['problems']) && is_array($panic['problems'])) {
            foreach ($panic['problems'] as $problemId) {
                if (isset($interventions[$problemId]) && isset($interventions[$problemId]['price'])) {
                    $totalPrice += $interventions[$problemId]['price'];
                }
            }
        }
        
        $updateData = [
            'progress' => $progress,
            'total_price' => $totalPrice,
            'updated_at' => date('Y-m-d H:i:s')
        ];
        
        if ($progress >= 100) {
            $updateData['status'] = 'completed';
            $updateData['completed_at'] = date('Y-m-d H:i:s');
        }
        
        return $this->updateDocument('pannes', $panicId, $updateData);
    }
    
    /**
     * Obtenir les statistiques pour le dashboard web
     */
    public function getStatistics()
    {
        $pannes = [];
        $url = $this->getBaseUrl() . "/pannes?key=" . $this->apiKey;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            
            if (isset($data['documents'])) {
                foreach ($data['documents'] as $doc) {
                    $fields = $this->convertFromFirestore($doc['fields']);
                    $pannes[] = $fields;
                }
            }
        }
        
        // Calculer les statistiques
        $stats = [
            'total_pannes' => count($pannes),
            'pannes_waiting' => 0,
            'pannes_in_repair' => 0,
            'pannes_completed' => 0,
            'total_revenue' => 0,
            'occupied_slots' => 0
        ];
        
        foreach ($pannes as $panne) {
            if (isset($panne['status'])) {
                switch ($panne['status']) {
                    case 'waiting':
                        $stats['pannes_waiting']++;
                        break;
                    case 'in_repair':
                        $stats['pannes_in_repair']++;
                        $stats['occupied_slots']++;
                        break;
                    case 'completed':
                        $stats['pannes_completed']++;
                        if (isset($panne['total_price'])) {
                            $stats['total_revenue'] += $panne['total_price'];
                        }
                        break;
                }
            }
        }
        
        // Ajouter le nombre d'utilisateurs
        $users = $this->getUsers();
        $stats['total_users'] = count($users);
        
        // Ajouter les interventions disponibles
        $interventions = $this->getInterventions();
        $stats['available_interventions'] = count($interventions);
        
        return $stats;
    }
    
    // ==================== MÉTHODES UTILITAIRES ====================
    
    private function createDocument($collection, $documentId, $data)
    {
        $url = $this->getBaseUrl() . "/{$collection}?key=" . $this->apiKey . "&documentId={$documentId}";
        
        $fields = [];
        foreach ($data as $key => $value) {
            $fields[$key] = $this->convertToFirestoreValue($value);
        }
        
        $firestoreData = ['fields' => $fields];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'POST');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($firestoreData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return [
            'success' => $httpCode === 200,
            'document_id' => $documentId,
            'response' => json_decode($response, true)
        ];
    }
    
    private function getDocument($collection, $documentId)
    {
        $url = $this->getBaseUrl() . "/{$collection}/{$documentId}?key=" . $this->apiKey;
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        if ($httpCode === 200) {
            $data = json_decode($response, true);
            if (isset($data['fields'])) {
                return $this->convertFromFirestore($data['fields']);
            }
        }
        
        return null;
    }
    
    private function updateDocument($collection, $documentId, $data)
    {
        $url = $this->getBaseUrl() . "/{$collection}/{$documentId}?key=" . $this->apiKey;
        
        $fields = [];
        foreach ($data as $key => $value) {
            $fields[$key] = $this->convertToFirestoreValue($value);
        }
        
        $firestoreData = [
            'fields' => $fields,
            'mask' => ['fieldPaths' => array_keys($fields)]
        ];
        
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'PATCH');
        curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($firestoreData));
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        
        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        curl_close($ch);
        
        return [
            'success' => $httpCode === 200,
            'response' => json_decode($response, true)
        ];
    }
    
    private function convertToFirestoreValue($value)
    {
        if (is_string($value)) {
            return ['stringValue' => $value];
        } elseif (is_int($value)) {
            return ['integerValue' => $value];
        } elseif (is_bool($value)) {
            return ['booleanValue' => $value];
        } elseif (is_array($value)) {
            $values = [];
            foreach ($value as $item) {
                if (is_string($item)) {
                    $values[] = ['stringValue' => $item];
                } elseif (is_int($item)) {
                    $values[] = ['integerValue' => $item];
                }
            }
            return ['arrayValue' => ['values' => $values]];
        } else {
            return ['stringValue' => (string)$value];
        }
    }
    
    private function convertFromFirestore($fields)
    {
        $result = [];
        
        foreach ($fields as $key => $field) {
            if (isset($field['stringValue'])) {
                $result[$key] = $field['stringValue'];
            } elseif (isset($field['integerValue'])) {
                $result[$key] = (int)$field['integerValue'];
            } elseif (isset($field['booleanValue'])) {
                $result[$key] = (bool)$field['booleanValue'];
            } elseif (isset($field['arrayValue']['values'])) {
                $array = [];
                foreach ($field['arrayValue']['values'] as $value) {
                    if (isset($value['stringValue'])) {
                        $array[] = $value['stringValue'];
                    } elseif (isset($value['integerValue'])) {
                        $array[] = (int)$value['integerValue'];
                    }
                }
                $result[$key] = $array;
            }
        }
        
        return $result;
    }
    
    private function extractDocumentId($path)
    {
        $parts = explode('/', $path);
        return end($parts);
    }
}