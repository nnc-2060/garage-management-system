# Changelog

Toutes les modifications notables de ce projet seront documentées dans ce fichier.

## [1.0.0] - 2026-02-08

### ✨ Fonctionnalités ajoutées

#### Système de base
- ✅ Intégration complète Firebase Realtime Database
- ✅ Réception automatique des pannes depuis Firebase
- ✅ Synchronisation bidirectionnelle (jeu → Firebase)
- ✅ Polling configurable (défaut: 2 secondes)

#### Gameplay
- ✅ Contrôle fluide du mécanicien (ZQSD + flèches)
- ✅ Animations directionnelles (top, down, left, right, idle)
- ✅ Système de détection de proximité avec les voitures
- ✅ Interaction avec les voitures (touche E ou Espace)
- ✅ Menu de sélection des pannes
- ✅ Progression automatique des réparations
- ✅ Support de 2 voitures simultanément
- ✅ Gestion de priorités des réparations

#### Interface utilisateur
- ✅ Barre supérieure avec statistiques en temps réel
  - Statut Firebase
  - Nombre de voitures actives
  - Gains de la session
- ✅ Menu de réparation par voiture
- ✅ Barres de progression visuelles
- ✅ Système de notifications
- ✅ Affichage des informations client/voiture

#### Architecture technique
- ✅ 4 Autoloads (Singletons)
  - FirebaseManager : Gestion Firebase
  - DataManager : État des pannes
  - GameManager : Orchestration
  - RepairProgressManager : Timers de réparation
- ✅ Structure modulaire et extensible
- ✅ Système d'événements (signals)
- ✅ Gestion d'erreurs robuste

#### Assets et design
- ✅ Sprite du mécanicien avec animations
- ✅ Background du garage avec collisions
- ✅ Sprites de voitures
- ✅ UI moderne avec panels stylisés

#### Documentation
- ✅ README complet avec architecture
- ✅ Guide de démarrage rapide (QUICKSTART.md)
- ✅ Exemple de données Firebase
- ✅ Scripts de test unitaires
- ✅ Commentaires détaillés dans le code

### 🎨 Design et UX
- Interface moderne avec couleurs cohérentes
- Feedback visuel pour toutes les interactions
- Animations fluides (fade in/out)
- Surbrillance des voitures au survol

### 🔧 Technique
- Collision layers bien configurées
- Physics optimisées
- Gestion mémoire propre (queue_free)
- Pas de memory leaks

### 📊 Statistiques
- Suivi des gains totaux
- Compteur de pannes complétées
- Durée de session
- Gains par heure

### 🌐 Firebase
- Structure de données optimisée
- Validation des données entrantes
- Cache local des pannes
- Détection des changements
- Envoi des mises à jour de statut

### 📦 Livrables
- Projet Godot complet et fonctionnel
- Configuration Firebase avec exemples
- Documentation exhaustive
- Données de test prêtes à l'emploi

---

## [Prochaines versions] - À venir

### 🚀 Fonctionnalités planifiées

#### v1.1.0 - Améliorations gameplay
- [ ] Système de niveaux et progression
- [ ] Déblocage d'outils spéciaux
- [ ] Plusieurs mécaniciens simultanés
- [ ] Système de fatigue du mécanicien
- [ ] Différents types de pannes (urgentes, normales, rapides)

#### v1.2.0 - Expansion contenu
- [ ] Plus de types de voitures
- [ ] Personnalisation du garage
- [ ] Système d'amélioration du garage
- [ ] Musique et effets sonores
- [ ] Particules et effets visuels

#### v1.3.0 - Fonctionnalités avancées
- [ ] Mode multijoueur coopératif
- [ ] Système de réputation
- [ ] Clients réguliers avec bonus
- [ ] Défis quotidiens
- [ ] Succès/Achievements

#### v2.0.0 - Expansion majeure
- [ ] Mode campagne avec histoire
- [ ] Gestion d'entreprise (employés, budget)
- [ ] Système économique avancé
- [ ] Marché des pièces détachées
- [ ] Mode sandbox illimité

### 🐛 Bugs connus
- Aucun bug connu pour le moment

### 📝 Notes de développement
- Projet créé avec Godot 4.3
- Compatible Godot 4.2+
- Testé sur Windows, Linux
- Compatible avec Firebase Realtime Database
- Intégration Ionic testée et validée

---

## Convention de versioning

Ce projet suit [Semantic Versioning](https://semver.org/):
- **MAJOR** : Changements incompatibles
- **MINOR** : Nouvelles fonctionnalités compatibles
- **PATCH** : Corrections de bugs

## Format du changelog

Inspiré de [Keep a Changelog](https://keepachangelog.com/)

### Types de changements
- **Added** : Nouvelles fonctionnalités
- **Changed** : Modifications de fonctionnalités existantes
- **Deprecated** : Fonctionnalités bientôt retirées
- **Removed** : Fonctionnalités retirées
- **Fixed** : Corrections de bugs
- **Security** : Corrections de sécurité
