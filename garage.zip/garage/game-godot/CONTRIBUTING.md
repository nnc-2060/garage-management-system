# 🤝 Guide de contribution

Merci de votre intérêt pour contribuer au projet Garage Repair Simulator !

## 🎯 Comment contribuer

### Rapporter un bug

1. Vérifiez que le bug n'a pas déjà été rapporté
2. Créez une issue avec :
   - Description claire du problème
   - Étapes pour reproduire
   - Comportement attendu vs actuel
   - Screenshots si pertinent
   - Version de Godot utilisée
   - Logs de la console

### Proposer une fonctionnalité

1. Créez une issue pour discuter de la fonctionnalité
2. Attendez les retours avant de commencer le développement
3. Assurez-vous que cela s'aligne avec la vision du projet

### Soumettre du code

1. Forkez le repository
2. Créez une branche (`git checkout -b feature/amazing-feature`)
3. Committez vos changements (`git commit -m 'Add amazing feature'`)
4. Pushez vers la branche (`git push origin feature/amazing-feature`)
5. Ouvrez une Pull Request

## 📝 Standards de code

### GDScript

```gdscript
# ✅ Bon
extends Node

## Documentation de la classe
## Utilise des commentaires Markdown

## Variables exportées en premier
@export var speed: float = 200.0

## Variables privées avec underscore
var _private_variable: int = 0

## Fonctions publiques
func public_function() -> void:
	pass

## Fonctions privées avec underscore
func _private_function() -> void:
	pass
```

### Conventions de nommage

- **Variables** : `snake_case`
- **Fonctions** : `snake_case`
- **Constantes** : `SCREAMING_SNAKE_CASE`
- **Classes** : `PascalCase`
- **Signals** : `snake_case`
- **Fichiers** : `snake_case.gd`
- **Scènes** : `snake_case.tscn`

### Documentation

```gdscript
## Brève description de la fonction
##
## Description détaillée si nécessaire.
## Peut utiliser plusieurs lignes.
##
## @param param1: Description du paramètre
## @param param2: Description du paramètre
## @return: Description du retour
func documented_function(param1: int, param2: String) -> bool:
	return true
```

### Organisation du code

```gdscript
extends Node

# 1. Signaux
signal something_happened(data)

# 2. Constantes
const MAX_SPEED = 100

# 3. Variables exportées
@export var speed: float = 50.0

# 4. Variables publiques
var public_var: int = 0

# 5. Variables privées
var _private_var: int = 0

# 6. Références aux nœuds
@onready var sprite: Sprite2D = $Sprite2D

# 7. Fonctions intégrées (_ready, _process, etc.)
func _ready() -> void:
	pass

func _process(delta: float) -> void:
	pass

# 8. Fonctions publiques
func public_function() -> void:
	pass

# 9. Fonctions privées
func _private_function() -> void:
	pass

# 10. Classes internes
class InnerClass:
	pass
```

## 🧪 Tests

### Tests manuels

Avant de soumettre :
1. Tester toutes les fonctionnalités modifiées
2. Vérifier qu'aucun bug n'a été introduit
3. Tester sur différentes résolutions
4. Vérifier les logs de console

### Tests unitaires

Si vous ajoutez une nouvelle fonctionnalité importante :
1. Ajouter des tests dans `tests/`
2. S'assurer que tous les tests passent

## 📐 Structure du projet

```
garage_game/
├── autoload/          # Singletons globaux
├── Scene/             # Scènes principales
├── script/            # Scripts GDScript
├── ui/                # Scripts d'interface
├── assets/            # Images, sprites, sons
├── tests/             # Tests unitaires
└── README.md          # Documentation
```

### Où ajouter votre code

- **Nouveau système global** → `autoload/`
- **Nouvelle scène** → `Scene/`
- **Nouveau script** → `script/`
- **Nouvelle UI** → `ui/`
- **Nouveaux assets** → `assets/`

## 🎨 Assets

### Images

- Format : PNG (sprites) ou JPG (backgrounds)
- Résolution : Multiples de 128px recommandé
- Compression : Optimisée pour le web
- Nommage : `snake_case.png`

### Sprites

- Utiliser des sprite sheets quand possible
- Documenter la grille (taille des frames)
- Fournir un fichier de configuration

## 🔥 Firebase

### Structure des données

Toujours respecter la structure :

```json
{
  "garage": {
	"pannes": {
	  "panne_id": {
		"timestamp": 0,
		"status": "pending",
		"client": {...},
		"car": {...},
		"repairs": [...]
	  }
	}
  }
}
```

### Modifications Firebase

Si vous modifiez la structure :
1. Mettre à jour `firebase_test_data.json`
2. Mettre à jour la documentation
3. Assurer la rétrocompatibilité

## ✅ Checklist avant Pull Request

- [ ] Le code suit les conventions de style
- [ ] Les fonctions sont documentées
- [ ] Le code est testé
- [ ] Aucun warning dans la console
- [ ] Les assets sont optimisés
- [ ] Le README est à jour si nécessaire
- [ ] Le CHANGELOG est mis à jour
- [ ] Les commits sont clairs et atomiques

## 💬 Communication

### Messages de commit

Format :
```
<type>(<scope>): <subject>

<body>

<footer>
```

Types :
- `feat`: Nouvelle fonctionnalité
- `fix`: Correction de bug
- `docs`: Documentation
- `style`: Formatage (pas de changement de code)
- `refactor`: Refactoring
- `test`: Tests
- `chore`: Maintenance

Exemples :
```
feat(voiture): Ajout animation d'arrivée
fix(firebase): Correction du parsing JSON
docs(readme): Mise à jour de la doc Firebase
```

### Pull Requests

Titre clair et descriptif :
```
feat: Ajout du système de niveaux
fix: Correction du spawn des voitures
docs: Amélioration de la documentation
```

Description :
```markdown
## Description
Brève description des changements

## Type de changement
- [ ] Bug fix
- [ ] Nouvelle fonctionnalité
- [ ] Breaking change
- [ ] Documentation

## Tests effectués
- Test 1
- Test 2

## Screenshots (si UI)
[image]

## Checklist
- [x] Mon code suit les conventions
- [x] J'ai testé mes changements
- [x] J'ai mis à jour la documentation
```

## 🎓 Apprendre

### Ressources

- [Documentation Godot](https://docs.godotengine.org/)
- [GDScript Style Guide](https://docs.godotengine.org/en/stable/tutorials/scripting/gdscript/gdscript_styleguide.html)
- [Firebase Documentation](https://firebase.google.com/docs)

### Tutoriels projet

Consulter :
- `QUICKSTART.md` pour démarrer
- `README.md` pour l'architecture
- Les commentaires dans le code

## ❓ Questions

Pour toute question :
1. Consulter la documentation existante
2. Chercher dans les issues fermées
3. Créer une nouvelle issue avec le tag `question`

## 🙏 Remerciements

Merci pour votre contribution ! Chaque contribution, petite ou grande, est appréciée.

Contributeurs : Voir la liste dans [CONTRIBUTORS.md](CONTRIBUTORS.md)
