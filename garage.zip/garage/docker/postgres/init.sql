-- docker/postgres/init.sql
-- Initialisation de la base de données PostgreSQL

-- Table des utilisateurs
CREATE TABLE IF NOT EXISTS users (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255) UNIQUE NOT NULL,
    email_verified_at TIMESTAMP NULL,
    password VARCHAR(255) NOT NULL,
    role VARCHAR(20) DEFAULT 'client' CHECK (role IN ('admin', 'mechanic', 'client')),
    phone VARCHAR(20),
    address TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des interventions
CREATE TABLE IF NOT EXISTS interventions (
    id SERIAL PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    price DECIMAL(10, 2) NOT NULL,
    duration_seconds INTEGER NOT NULL,
    difficulty VARCHAR(10) DEFAULT 'medium' CHECK (difficulty IN ('easy', 'medium', 'hard')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des véhicules
CREATE TABLE IF NOT EXISTS vehicles (
    id SERIAL PRIMARY KEY,
    user_id INTEGER REFERENCES users(id) ON DELETE SET NULL,
    brand VARCHAR(100) NOT NULL,
    model VARCHAR(100) NOT NULL,
    year INTEGER,
    license_plate VARCHAR(20) UNIQUE NOT NULL,
    color VARCHAR(50),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Table des réparations
CREATE TABLE IF NOT EXISTS repairs (
    id SERIAL PRIMARY KEY,
    vehicle_id INTEGER REFERENCES vehicles(id) ON DELETE CASCADE,
    status VARCHAR(20) DEFAULT 'waiting' CHECK (status IN ('waiting', 'in_repair', 'completed', 'cancelled')),
    total_price DECIMAL(10, 2),
    assigned_slot INTEGER CHECK (assigned_slot IN (1, 2)),
    progress INTEGER DEFAULT 0 CHECK (progress >= 0 AND progress <= 100),
    firebase_panic_id VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    started_at TIMESTAMP NULL,
    completed_at TIMESTAMP NULL
);

-- Table de liaison réparations-interventions
CREATE TABLE IF NOT EXISTS repair_interventions (
    id SERIAL PRIMARY KEY,
    repair_id INTEGER REFERENCES repairs(id) ON DELETE CASCADE,
    intervention_id INTEGER REFERENCES interventions(id) ON DELETE CASCADE,
    status VARCHAR(20) DEFAULT 'pending' CHECK (status IN ('pending', 'in_progress', 'completed')),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insertion des 8 interventions de base
INSERT INTO interventions (name, description, price, duration_seconds, difficulty) VALUES
('Frein', 'Remplacement des plaquettes et disques de frein', 150.00, 1800, 'medium'),
('Vidange', 'Vidange d huile moteur et remplacement du filtre à huile', 80.00, 900, 'easy'),
('Filtre', 'Remplacement du filtre à air et filtre d habitacle', 60.00, 600, 'easy'),
('Batterie', 'Remplacement de la batterie', 120.00, 600, 'easy'),
('Amortisseurs', 'Remplacement paire amortisseurs', 200.00, 3600, 'hard'),
('Embrayage', 'Remplacement du kit embrayage complet', 400.00, 7200, 'hard'),
('Pneus', 'Remplacement et équilibrage de 4 pneus', 300.00, 2400, 'medium'),
('Système de refroidissement', 'Vidange et remplissage liquide de refroidissement', 100.00, 1200, 'medium')
ON CONFLICT DO NOTHING;

-- Création d un utilisateur admin par défaut
INSERT INTO users (name, email, password, role) VALUES
('Administrateur', 'admin@garage.com', '$2y$10$92IXUNpkjO0rOQ5byMi.Ye4oKoEa3Ro9llC/.og/at2.uheWG/igi', 'admin')
ON CONFLICT (email) DO NOTHING;

-- Création d'index pour améliorer les performances
CREATE INDEX IF NOT EXISTS idx_repairs_status ON repairs(status);
CREATE INDEX IF NOT EXISTS idx_repairs_assigned_slot ON repairs(assigned_slot);
CREATE INDEX IF NOT EXISTS idx_users_email ON users(email);
CREATE INDEX IF NOT EXISTS idx_vehicles_license_plate ON vehicles(license_plate);