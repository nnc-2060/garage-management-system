<!-- web-frontend/src/App.vue -->
<template>
  <div id="app">
    <!-- Navigation simple -->
    <nav class="main-nav">
      <router-link to="/dashboard" class="nav-link">
        📊 Dashboard
      </router-link>
      <router-link to="/firebase-test" class="nav-link">
        🔥 Test Firebase
      </router-link>
    </nav>
    
    <main class="main-content">
      <router-view />
    </main>
  </div>
</template>

<script>
export default {
  name: 'App'
}
</script>

<style>
* {
  margin: 0;
  padding: 0;
  box-sizing: border-box;
}

body {
  font-family: -apple-system, BlinkMacSystemFont, 'Segoe UI', Roboto, Oxygen, Ubuntu, sans-serif;
  background: #f5f7fa;
  color: #333;
}

#app {
  min-height: 100vh;
}

.main-nav {
  background: white;
  padding: 20px;
  box-shadow: 0 2px 10px rgba(0,0,0,0.1);
  display: flex;
  gap: 20px;
}

.nav-link {
  color: #667eea;
  text-decoration: none;
  font-weight: 600;
  padding: 10px 20px;
  border-radius: 8px;
  transition: all 0.3s;
}

.nav-link:hover {
  background: #f0f4ff;
}

.nav-link.router-link-active {
  background: #667eea;
  color: white;
}

.main-content {
  padding: 20px;
}
</style>