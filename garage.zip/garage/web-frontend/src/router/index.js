// web-frontend/src/router/index.js
import { createRouter, createWebHistory } from 'vue-router'
import DashboardPage from '../views/DashboardPage.vue'
import FirebaseTest from '../views/FirebaseTest.vue'

const routes = [
  {
    path: '/',
    redirect: '/dashboard'
  },
  {
    path: '/dashboard',
    name: 'Dashboard',
    component: DashboardPage
  },
  {
    path: '/firebase-test',
    name: 'FirebaseTest',
    component: FirebaseTest
  }
]

const router = createRouter({
  history: createWebHistory(),
  routes
})

export default router