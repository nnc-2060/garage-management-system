<!-- web-frontend/src/views/StatisticsPage.vue -->
<template>
  <div class="statistics-page">
    <h1>📊 Statistiques Détaillées</h1>
    <!-- À compléter si besoin de plus de détails -->
  </div>
</template>