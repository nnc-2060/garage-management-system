<!-- web-frontend/src/views/DashboardPage.vue -->
<template>
  <div class="dashboard-page">
    <!-- En-tête -->
    <div class="dashboard-header">
      <h1>📊 Dashboard Garage</h1>
      <div class="header-info">
        <span class="status-badge online">🟢 En ligne</span>
        <span class="last-update">Dernière mise à jour: {{ lastUpdate }}</span>
        <button @click="refreshData" class="refresh-btn">
          🔄 Actualiser
        </button>
      </div>
    </div>

    <!-- Statistiques principales -->
    <div class="stats-section">
      <h2>📈 Statistiques Globales</h2>
      <div class="stats-grid">
        <div class="stat-card">
          <div class="stat-icon">🚗</div>
          <div class="stat-content">
            <h3>{{ statistics.total_pannes || 0 }}</h3>
            <p>Total Pannes</p>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">⏳</div>
          <div class="stat-content">
            <h3>{{ statistics.pannes_waiting || 0 }}</h3>
            <p>En Attente</p>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">🔧</div>
          <div class="stat-content">
            <h3>{{ statistics.pannes_in_repair || 0 }}</h3>
            <p>En Réparation</p>
            <small>{{ availableSlots }}/2 slots disponibles</small>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">✅</div>
          <div class="stat-content">
            <h3>{{ statistics.pannes_completed || 0 }}</h3>
            <p>Terminées</p>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">💰</div>
          <div class="stat-content">
            <h3>{{ formatCurrency(statistics.total_revenue || 0) }}</h3>
            <p>Revenu Total</p>
          </div>
        </div>

        <div class="stat-card">
          <div class="stat-icon">👥</div>
          <div class="stat-content">
            <h3>{{ statistics.total_users || 0 }}</h3>
            <p>Clients</p>
          </div>
        </div>
      </div>
    </div>

    <!-- Réparations en cours -->
    <div class="repairs-section">
      <div class="section-header">
        <h2>🔧 Réparations en Cours</h2>
        <span class="badge">{{ activeRepairs.length }}</span>
      </div>

      <div v-if="activeRepairs.length > 0" class="repairs-grid">
        <div v-for="repair in activeRepairs" :key="repair.id" class="repair-card">
          <div class="repair-header">
            <div class="slot-info">
              <span class="slot-badge">Slot {{ repair.assigned_slot || 'N/A' }}</span>
              <span class="progress-badge">{{ repair.progress || 0 }}%</span>
            </div>
            <div class="progress-bar">
              <div class="progress-fill" :style="{ width: repair.progress + '%' }"></div>
            </div>
          </div>

          <div class="vehicle-info">
            <h4>{{ repair.car_brand }} {{ repair.car_model }}</h4>
            <div class="vehicle-details">
              <span class="license-plate">{{ repair.license_plate }}</span>
              <span class="year">{{ repair.car_year }}</span>
            </div>
          </div>

          <div class="problems-list">
            <h5>Interventions :</h5>
            <div class="problems-tags">
              <span v-for="problem in repair.problems" :key="problem" class="problem-tag">
                {{ getInterventionName(problem) }}
              </span>
            </div>
          </div>

          <div class="repair-footer">
            <div class="client-info">
              <span>👤 {{ repair.owner_name || 'Client' }}</span>
              <span>📞 {{ repair.owner_phone || 'N/A' }}</span>
            </div>
            <div class="price-info">
              <span class="price">{{ formatCurrency(repair.total_price || 0) }}</span>
            </div>
          </div>
        </div>
      </div>

      <div v-else class="empty-state">
        <p>Aucune réparation en cours</p>
      </div>
    </div>

    <!-- Voitures en attente -->
    <div class="waiting-section">
      <div class="section-header">
        <h2>🚘 Voitures en Attente</h2>
        <span class="badge">{{ waitingCars.length }}</span>
      </div>

      <div v-if="waitingCars.length > 0" class="waiting-grid">
        <div v-for="car in waitingCars" :key="car.id" class="waiting-card">
          <div class="car-header">
            <h4>{{ car.car_brand }} {{ car.car_model }}</h4>
            <span class="priority-badge" :class="getPriorityClass(car.priority)">
              {{ car.priority || 'normal' }}
            </span>
          </div>

          <div class="car-details">
            <p><strong>Immatriculation:</strong> {{ car.license_plate }}</p>
            <p><strong>Année:</strong> {{ car.car_year }}</p>
            <p><strong>Client:</strong> {{ car.owner_name || car.user_id }}</p>
            <p><strong>Date d'arrivée:</strong> {{ formatDate(car.created_at) }}</p>
          </div>

          <div class="car-problems">
            <p><strong>Problèmes détectés:</strong></p>
            <div class="problems-list">
              <span v-for="problem in car.problems" :key="problem" class="problem-tag small">
                {{ getInterventionName(problem) }}
              </span>
            </div>
          </div>

          <div class="car-actions">
            <button @click="assignToSlot(car)" class="btn-action" :disabled="availableSlots === 0">
              Assigner à un slot
            </button>
            <button @click="viewDetails(car)" class="btn-action outline">
              Détails
            </button>
          </div>
        </div>
      </div>

      <div v-else class="empty-state">
        <p>Aucune voiture en attente</p>
      </div>
    </div>

    <!-- Interventions disponibles -->
    <div class="interventions-section">
      <h2>🛠️ Interventions Disponibles</h2>
      <div class="interventions-grid">
        <div v-for="intervention in interventions" :key="intervention.id" class="intervention-card">
          <h4>{{ intervention.name }}</h4>
          <p class="price">{{ formatCurrency(intervention.price) }}</p>
          <p class="description">{{ intervention.description }}</p>
          <div class="intervention-meta">
            <span class="duration">⏱️ {{ intervention.duration_seconds }}s</span>
            <span class="difficulty" :class="intervention.difficulty">
              {{ intervention.difficulty }}
            </span>
          </div>
        </div>
      </div>
    </div>

    <!-- Chargement -->
    <div v-if="loading" class="loading-overlay">
      <div class="spinner"></div>
      <p>Chargement des données...</p>
    </div>
  </div>
</template>

<script>
import api from '../services/api.js'

export default {
  name: 'DashboardPage',
  data() {
    return {
      loading: false,
      statistics: {},
      activeRepairs: [],
      waitingCars: [],
      interventions: [],
      lastUpdate: '--:--',
      interventionsMap: {}
    }
  },
  computed: {
    availableSlots() {
      const inRepair = this.statistics.pannes_in_repair || 0
      return Math.max(0, 2 - inRepair)
    }
  },
  mounted() {
    this.loadDashboardData()
    // Rafraîchir toutes les 30 secondes
    this.refreshInterval = setInterval(() => {
      this.loadDashboardData()
    }, 30000)
  },
  beforeUnmount() {
    if (this.refreshInterval) {
      clearInterval(this.refreshInterval)
    }
  },
  methods: {
    async loadDashboardData() {
      this.loading = true
      try {
        // Charger toutes les données en parallèle
        const [dashboardRes, waitingRes, interventionsRes] = await Promise.all([
          api.get('/firebase/dashboard'),
          api.get('/firebase/pannes/waiting'),
          api.get('/firebase/interventions')
        ])

        if (dashboardRes.data.success) {
          this.statistics = dashboardRes.data.dashboard.statistics || {}
          this.activeRepairs = dashboardRes.data.dashboard.in_repair_pannes || []
        }

        if (waitingRes.data.success) {
          this.waitingCars = waitingRes.data.data || []
        }

        if (interventionsRes.data.success) {
          this.interventions = Object.values(interventionsRes.data.data || {})
          
          // Créer une map pour les noms d'interventions
          this.interventionsMap = {}
          Object.entries(interventionsRes.data.data || {}).forEach(([id, intervention]) => {
            this.interventionsMap[id] = intervention.name || id
          })
        }

        this.lastUpdate = new Date().toLocaleTimeString('fr-FR')
        
      } catch (error) {
        console.error('Erreur de chargement:', error)
      } finally {
        this.loading = false
      }
    },

    async refreshData() {
      await this.loadDashboardData()
    },

    getInterventionName(problemId) {
      return this.interventionsMap[problemId] || problemId
    },

    formatCurrency(amount) {
      return new Intl.NumberFormat('fr-FR', {
        style: 'currency',
        currency: 'EUR'
      }).format(amount)
    },

    formatDate(dateString) {
      if (!dateString) return 'N/A'
      return new Date(dateString).toLocaleDateString('fr-FR', {
        day: '2-digit',
        month: '2-digit',
        year: 'numeric',
        hour: '2-digit',
        minute: '2-digit'
      })
    },

    getPriorityClass(priority) {
      const classes = {
        'high': 'high',
        'medium': 'medium',
        'low': 'low'
      }
      return classes[priority] || 'medium'
    },

    async assignToSlot(car) {
      if (this.availableSlots === 0) {
        alert('Tous les slots sont occupés (max 2)')
        return
      }

      try {
        const slotNumber = this.activeRepairs.length + 1 // 1 ou 2
        const response = await api.post('/firebase/assign-to-slot', {
          panic_id: car.firebase_id || car.id,
          slot_number: slotNumber
        })

        if (response.data.success) {
          alert(`Voiture assignée au slot ${slotNumber}`)
          this.refreshData()
        } else {
          alert(response.data.message || 'Erreur')
        }
      } catch (error) {
        console.error('Erreur:', error)
        alert('Erreur lors de l\'assignation')
      }
    },

    viewDetails(car) {
      // Pour l'instant, afficher les détails dans la console
      console.log('Détails voiture:', car)
      alert(`Détails de ${car.car_brand} ${car.car_model}`)
    }
  }
}
</script>

<style scoped>
.dashboard-page {
  padding: 20px;
  max-width: 1400px;
  margin: 0 auto;
}

.dashboard-header {
  background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
  color: white;
  padding: 30px;
  border-radius: 15px;
  margin-bottom: 30px;
  box-shadow: 0 10px 30px rgba(0,0,0,0.1);
}

.dashboard-header h1 {
  margin: 0;
  font-size: 2.5em;
}

.header-info {
  display: flex;
  align-items: center;
  gap: 20px;
  margin-top: 15px;
  flex-wrap: wrap;
}

.status-badge {
  background: rgba(255,255,255,0.2);
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 0.9em;
}

.status-badge.online {
  background: rgba(46, 204, 113, 0.2);
}

.last-update {
  opacity: 0.9;
}

.refresh-btn {
  background: white;
  color: #667eea;
  border: none;
  padding: 8px 20px;
  border-radius: 20px;
  cursor: pointer;
  font-weight: 600;
  transition: transform 0.3s;
}

.refresh-btn:hover {
  transform: translateY(-2px);
}

/* Statistiques */
.stats-section {
  margin-bottom: 40px;
}

.stats-section h2 {
  color: #2c3e50;
  margin-bottom: 20px;
}

.stats-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
  gap: 20px;
}

.stat-card {
  background: white;
  padding: 25px;
  border-radius: 12px;
  box-shadow: 0 5px 15px rgba(0,0,0,0.05);
  display: flex;
  align-items: center;
  gap: 20px;
  border-left: 5px solid #667eea;
  transition: transform 0.3s;
}

.stat-card:hover {
  transform: translateY(-5px);
}

.stat-icon {
  font-size: 2.5em;
  opacity: 0.8;
}

.stat-content h3 {
  margin: 0;
  font-size: 2em;
  color: #2c3e50;
}

.stat-content p {
  margin: 5px 0 0 0;
  color: #7f8c8d;
  font-size: 0.9em;
}

.stat-content small {
  color: #95a5a6;
  font-size: 0.8em;
}

/* Sections */
.repairs-section, .waiting-section, .interventions-section {
  background: white;
  padding: 30px;
  border-radius: 15px;
  margin-bottom: 30px;
  box-shadow: 0 5px 15px rgba(0,0,0,0.05);
}

.section-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 25px;
  padding-bottom: 15px;
  border-bottom: 2px solid #f1f2f6;
}

.section-header h2 {
  margin: 0;
  color: #2c3e50;
}

.badge {
  background: #667eea;
  color: white;
  padding: 5px 15px;
  border-radius: 20px;
  font-size: 0.9em;
  font-weight: 600;
}

/* Réparations */
.repairs-grid, .waiting-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(350px, 1fr));
  gap: 20px;
}

.repair-card, .waiting-card {
  background: #f8f9fa;
  border-radius: 10px;
  padding: 20px;
  border: 1px solid #e9ecef;
  transition: all 0.3s;
}

.repair-card:hover, .waiting-card:hover {
  transform: translateY(-3px);
  box-shadow: 0 10px 20px rgba(0,0,0,0.1);
}

.repair-header {
  margin-bottom: 15px;
}

.slot-info {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 10px;
}

.slot-badge {
  background: #3498db;
  color: white;
  padding: 3px 10px;
  border-radius: 12px;
  font-size: 0.8em;
  font-weight: 600;
}

.progress-badge {
  background: #27ae60;
  color: white;
  padding: 3px 10px;
  border-radius: 12px;
  font-size: 0.8em;
  font-weight: 600;
}

.progress-bar {
  height: 8px;
  background: #ecf0f1;
  border-radius: 4px;
  overflow: hidden;
}

.progress-fill {
  height: 100%;
  background: linear-gradient(90deg, #2ecc71, #27ae60);
  transition: width 0.5s ease;
}

.vehicle-info h4 {
  margin: 0 0 5px 0;
  color: #2c3e50;
}

.vehicle-details {
  display: flex;
  gap: 10px;
  margin-bottom: 15px;
}

.license-plate {
  background: #2c3e50;
  color: white;
  padding: 2px 8px;
  border-radius: 4px;
  font-family: monospace;
  font-size: 0.9em;
}

.year {
  color: #7f8c8d;
  font-size: 0.9em;
}

.problems-list h5 {
  margin: 0 0 10px 0;
  color: #2c3e50;
}

.problems-tags {
  display: flex;
  flex-wrap: wrap;
  gap: 5px;
}

.problem-tag {
  background: #e3f2fd;
  color: #1976d2;
  padding: 4px 10px;
  border-radius: 15px;
  font-size: 0.85em;
}

.problem-tag.small {
  font-size: 0.8em;
  padding: 2px 8px;
}

.repair-footer {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-top: 15px;
  padding-top: 15px;
  border-top: 1px solid #e9ecef;
}

.client-info {
  display: flex;
  flex-direction: column;
  gap: 5px;
  color: #7f8c8d;
  font-size: 0.9em;
}

.price-info .price {
  font-size: 1.2em;
  font-weight: bold;
  color: #27ae60;
}

/* Voitures en attente */
.car-header {
  display: flex;
  justify-content: space-between;
  align-items: center;
  margin-bottom: 15px;
}

.car-header h4 {
  margin: 0;
  color: #2c3e50;
}

.priority-badge {
  padding: 3px 10px;
  border-radius: 12px;
  font-size: 0.8em;
  font-weight: 600;
}

.priority-badge.high {
  background: #e74c3c;
  color: white;
}

.priority-badge.medium {
  background: #f39c12;
  color: white;
}

.priority-badge.low {
  background: #3498db;
  color: white;
}

.car-details p {
  margin: 5px 0;
  color: #555;
  font-size: 0.95em;
}

.car-actions {
  display: flex;
  gap: 10px;
  margin-top: 15px;
}

.btn-action {
  flex: 1;
  padding: 10px;
  border: none;
  border-radius: 8px;
  cursor: pointer;
  font-weight: 600;
  transition: all 0.3s;
}

.btn-action {
  background: #667eea;
  color: white;
}

.btn-action:hover:not(:disabled) {
  background: #5a67d8;
  transform: translateY(-2px);
}

.btn-action:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}

.btn-action.outline {
  background: transparent;
  color: #667eea;
  border: 2px solid #667eea;
}

.btn-action.outline:hover {
  background: #667eea;
  color: white;
}

/* Interventions */
.interventions-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
  gap: 20px;
}

.intervention-card {
  background: #f8f9fa;
  padding: 20px;
  border-radius: 10px;
  border: 1px solid #e9ecef;
}

.intervention-card h4 {
  margin: 0 0 10px 0;
  color: #2c3e50;
}

.intervention-card .price {
  font-size: 1.3em;
  font-weight: bold;
  color: #27ae60;
  margin: 10px 0;
}

.intervention-card .description {
  color: #7f8c8d;
  font-size: 0.9em;
  margin: 10px 0;
  line-height: 1.4;
}

.intervention-meta {
  display: flex;
  justify-content: space-between;
  margin-top: 15px;
  font-size: 0.85em;
}

.intervention-meta .duration {
  color: #7f8c8d;
}

.intervention-meta .difficulty {
  padding: 2px 8px;
  border-radius: 10px;
  font-weight: 600;
}

.intervention-meta .difficulty.easy {
  background: #d4edda;
  color: #155724;
}

.intervention-meta .difficulty.medium {
  background: #fff3cd;
  color: #856404;
}

.intervention-meta .difficulty.hard {
  background: #f8d7da;
  color: #721c24;
}

/* États vides */
.empty-state {
  text-align: center;
  padding: 40px;
  color: #95a5a6;
  font-style: italic;
}

/* Chargement */
.loading-overlay {
  position: fixed;
  top: 0;
  left: 0;
  right: 0;
  bottom: 0;
  background: rgba(255, 255, 255, 0.9);
  display: flex;
  flex-direction: column;
  justify-content: center;
  align-items: center;
  z-index: 1000;
}

.spinner {
  border: 4px solid #f3f3f3;
  border-top: 4px solid #667eea;
  border-radius: 50%;
  width: 50px;
  height: 50px;
  animation: spin 1s linear infinite;
  margin-bottom: 20px;
}

@keyframes spin {
  0% { transform: rotate(0deg); }
  100% { transform: rotate(360deg); }
}

@media (max-width: 768px) {
  .stats-grid {
    grid-template-columns: 1fr;
  }
  
  .repairs-grid, .waiting-grid {
    grid-template-columns: 1fr;
  }
  
  .interventions-grid {
    grid-template-columns: 1fr;
  }
  
  .dashboard-header {
    padding: 20px;
  }
  
  .dashboard-header h1 {
    font-size: 2em;
  }
  
  .header-info {
    flex-direction: column;
    align-items: flex-start;
    gap: 10px;
  }
}
</style>