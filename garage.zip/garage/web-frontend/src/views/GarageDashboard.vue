<!-- frontend-web/src/views/GarageDashboard.vue -->
<template>
    <div class="garage-dashboard">
        <!-- Header -->
        <div class="dashboard-header">
            <h1>🔧 Garage Simulation Dashboard</h1>
            <p>Surveillance en temps réel des réparations</p>
            
            <div class="header-stats">
                <div class="stat-badge" :class="connectionClass">
                    <span class="stat-icon">{{ isConnected ? '✅' : '❌' }}</span>
                    <span>{{ isConnected ? 'Firebase Connecté' : 'Déconnecté' }}</span>
                </div>
                <div class="stat-badge">
                    <span class="stat-icon">🕐</span>
                    <span>Dernière mise à jour: {{ lastUpdateTime }}</span>
                </div>
                <button @click="refreshAll" class="refresh-btn" :disabled="loading">
                    {{ loading ? 'Chargement...' : '🔄 Rafraîchir' }}
                </button>
            </div>
        </div>

        <!-- Statistiques principales -->
        <div class="main-stats">
            <div class="stat-card total">
                <div class="stat-icon">🚗</div>
                <div class="stat-content">
                    <h3>{{ dashboardData.statistics?.total_pannes || 0 }}</h3>
                    <p>Total Pannes</p>
                </div>
            </div>
            
            <div class="stat-card waiting">
                <div class="stat-icon">⏳</div>
                <div class="stat-content">
                    <h3>{{ dashboardData.statistics?.pannes_waiting || 0 }}</h3>
                    <p>En Attente</p>
                </div>
            </div>
            
            <div class="stat-card repairing">
                <div class="stat-icon">🔧</div>
                <div class="stat-content">
                    <h3>{{ dashboardData.statistics?.pannes_in_repair || 0 }}</h3>
                    <p>En Réparation</p>
                    <small>{{ dashboardData.garage_info?.available_slots || 0 }}/{{ dashboardData.garage_info?.max_slots || 2 }} slots libres</small>
                </div>
            </div>
            
            <div class="stat-card completed">
                <div class="stat-icon">✅</div>
                <div class="stat-content">
                    <h3>{{ dashboardData.statistics?.pannes_completed || 0 }}</h3>
                    <p>Terminées</p>
                </div>
            </div>
            
            <div class="stat-card revenue">
                <div class="stat-icon">💰</div>
                <div class="stat-content">
                    <h3>{{ formatCurrency(dashboardData.statistics?.total_revenue || 0) }}</h3>
                    <p>Revenu Total</p>
                </div>
            </div>
        </div>

        <!-- Sections principales -->
        <div class="dashboard-sections">
            <!-- Voitures en attente -->
            <div class="section waiting-cars">
                <div class="section-header">
                    <h2>🚘 Voitures en Attente</h2>
                    <span class="badge">{{ dashboardData.waiting_cars?.length || 0 }}</span>
                </div>
                
                <div v-if="dashboardData.waiting_cars && dashboardData.waiting_cars.length > 0" class="cars-list">
                    <div v-for="car in dashboardData.waiting_cars" :key="car.id" class="car-card">
                        <div class="car-header">
                            <h4>{{ car.car_brand }} {{ car.car_model }} ({{ car.car_year }})</h4>
                            <span class="license-plate">{{ car.license_plate }}</span>
                        </div>
                        
                        <div class="car-info">
                            <p><strong>Propriétaire:</strong> {{ car.owner_name || car.user_id }}</p>
                            <p><strong>Problèmes:</strong> {{ car.problems?.length || 0 }} intervention(s)</p>
                            <p><strong>Prix estimé:</strong> {{ formatCurrency(car.estimated_price || 0) }}</p>
                        </div>
                        
                        <div class="car-problems">
                            <span v-for="problem in car.intervention_details" :key="problem.id" class="problem-tag">
                                {{ problem.name }}
                            </span>
                        </div>
                    </div>
                </div>
                
                <div v-else class="empty-state">
                    <p>Aucune voiture en attente</p>
                </div>
            </div>

            <!-- Réparations en cours -->
            <div class="section active-repairs">
                <div class="section-header">
                    <h2>🔧 Réparations en Cours</h2>
                    <span class="badge">{{ dashboardData.active_repairs?.length || 0 }}</span>
                </div>
                
                <div v-if="dashboardData.active_repairs && dashboardData.active_repairs.length > 0" class="repairs-list">
                    <div v-for="repair in dashboardData.active_repairs" :key="repair.id" class="repair-card">
                        <div class="repair-header">
                            <h4>Slot {{ repair.assigned_slot || 'N/A' }}</h4>
                            <div class="progress-container">
                                <div class="progress-bar" :style="{ width: repair.progress + '%' }"></div>
                                <span class="progress-text">{{ repair.progress || 0 }}%</span>
                            </div>
                        </div>
                        
                        <div class="repair-info">
                            <p><strong>Véhicule:</strong> {{ repair.car_brand }} {{ repair.car_model }}</p>
                            <p><strong>Immatriculation:</strong> {{ repair.license_plate }}</p>
                            <p><strong>Progression:</strong></p>
                            <div class="progress-details">
                                <span v-for="intervention in repair.intervention_details" :key="intervention.id" class="intervention-tag">
                                    {{ intervention.name }}
                                </span>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div v-else class="empty-state">
                    <p>Aucune réparation en cours</p>
                </div>
            </div>

            <!-- Types de réparation -->
            <div class="section repair-types">
                <div class="section-header">
                    <h2>📋 Types de Réparation</h2>
                    <span class="badge">{{ dashboardData.repair_types?.length || 0 }}</span>
                </div>
                
                <div v-if="dashboardData.repair_types && dashboardData.repair_types.length > 0" class="types-grid">
                    <div v-for="type in dashboardData.repair_types" :key="type.id" class="type-card">
                        <h4>{{ type.name }}</h4>
                        <p class="type-price">{{ formatCurrency(type.price) }}</p>
                        <p class="type-desc">{{ type.description }}</p>
                        <div class="type-meta">
                            <span class="meta-tag">⏱️ {{ type.duration }}min</span>
                            <span class="meta-tag" :class="getDifficultyClass(type.difficulty)">
                                {{ type.difficulty }}
                            </span>
                        </div>
                    </div>
                </div>
                
                <div v-else class="empty-state">
                    <p>Aucun type de réparation disponible</p>
                </div>
            </div>
        </div>

        <!-- Information système -->
        <div class="system-info">
            <h3>📡 Information Système</h3>
            <div class="info-grid">
                <div class="info-item">
                    <span class="info-label">Projet Firebase:</span>
                    <span class="info-value">garagesimulator-17587</span>
                </div>
                <div class="info-item">
                    <span class="info-label">API Connectée:</span>
                    <span class="info-value" :class="{ connected: isConnected }">
                        {{ isConnected ? '✅ Oui' : '❌ Non' }}
                    </span>
                </div>
                <div class="info-item">
                    <span class="info-label">Utilisateurs:</span>
                    <span class="info-value">{{ dashboardData.statistics?.total_users || 0 }}</span>
                </div>
                <div class="info-item">
                    <span class="info-label">Temps d'attente estimé:</span>
                    <span class="info-value">{{ dashboardData.garage_info?.estimated_wait_time || 'N/A' }}</span>
                </div>
            </div>
        </div>

        <!-- Chargement et erreurs -->
        <div v-if="loading" class="loading-overlay">
            <div class="spinner"></div>
            <p>Chargement des données Firebase...</p>
        </div>
        
        <div v-if="error" class="error-message">
            <p>❌ Erreur: {{ error }}</p>
            <button @click="loadDashboard" class="retry-btn">Réessayer</button>
        </div>
    </div>
</template>

<script>
import axios from 'axios';

export default {
    name: 'GarageDashboard',
    data() {
        return {
            loading: false,
            error: null,
            isConnected: false,
            lastUpdateTime: '--:--',
            dashboardData: {
                statistics: {},
                active_repairs: [],
                waiting_cars: [],
                repair_types: [],
                garage_info: {}
            },
            refreshInterval: null
        };
    },
    computed: {
        connectionClass() {
            return this.isConnected ? 'connected' : 'disconnected';
        }
    },
    methods: {
        async loadDashboard() {
            this.loading = true;
            this.error = null;
            
            try {
                // Test de connexion
                const testResponse = await axios.get('/api/firebase/test');
                this.isConnected = testResponse.data.success;
                
                // Charger les données du dashboard
                const dashboardResponse = await axios.get('/api/firebase/dashboard');
                
                if (dashboardResponse.data.success) {
                    this.dashboardData = dashboardResponse.data.data;
                    this.lastUpdateTime = new Date().toLocaleTimeString('fr-FR');
                } else {
                    throw new Error(dashboardResponse.data.error || 'Erreur inconnue');
                }
                
            } catch (error) {
                console.error('Erreur de chargement:', error);
                this.error = error.message || 'Erreur de connexion au serveur';
                this.isConnected = false;
            } finally {
                this.loading = false;
            }
        },
        
        async refreshAll() {
            await this.loadDashboard();
        },
        
        formatCurrency(amount) {
            return new Intl.NumberFormat('fr-FR', {
                style: 'currency',
                currency: 'EUR'
            }).format(amount);
        },
        
        getDifficultyClass(difficulty) {
            const classes = {
                'easy': 'easy',
                'medium': 'medium',
                'hard': 'hard'
            };
            return classes[difficulty] || 'medium';
        }
    },
    mounted() {
        this.loadDashboard();
        
        // Rafraîchir automatiquement toutes les minutes
        this.refreshInterval = setInterval(() => {
            if (!this.loading) {
                this.loadDashboard();
            }
        }, 60000);
    },
    beforeUnmount() {
        if (this.refreshInterval) {
            clearInterval(this.refreshInterval);
        }
    }
};
</script>

<style scoped>
.garage-dashboard {
    padding: 20px;
    max-width: 1400px;
    margin: 0 auto;
    background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%);
    min-height: 100vh;
}

.dashboard-header {
    background: white;
    padding: 30px;
    border-radius: 15px;
    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
    margin-bottom: 30px;
}

.dashboard-header h1 {
    color: #2c3e50;
    margin-bottom: 10px;
    font-size: 2.2em;
}

.dashboard-header p {
    color: #7f8c8d;
    font-size: 1.1em;
}

.header-stats {
    display: flex;
    gap: 15px;
    margin-top: 20px;
    flex-wrap: wrap;
    align-items: center;
}

.stat-badge {
    background: #f8f9fa;
    padding: 10px 20px;
    border-radius: 25px;
    display: flex;
    align-items: center;
    gap: 8px;
    font-size: 0.9em;
    border: 1px solid #e9ecef;
}

.stat-badge.connected {
    background: #d4edda;
    color: #155724;
    border-color: #c3e6cb;
}

.stat-badge.disconnected {
    background: #f8d7da;
    color: #721c24;
    border-color: #f5c6cb;
}

.stat-icon {
    font-size: 1.2em;
}

.refresh-btn {
    background: #3498db;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 25px;
    cursor: pointer;
    display: flex;
    align-items: center;
    gap: 8px;
    transition: background 0.3s;
}

.refresh-btn:hover:not(:disabled) {
    background: #2980b9;
}

.refresh-btn:disabled {
    opacity: 0.5;
    cursor: not-allowed;
}

/* Statistiques principales */
.main-stats {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
    gap: 20px;
    margin-bottom: 30px;
}

.stat-card {
    background: white;
    padding: 25px;
    border-radius: 12px;
    display: flex;
    align-items: center;
    gap: 20px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
    transition: transform 0.3s;
}

.stat-card:hover {
    transform: translateY(-5px);
}

.stat-card.total {
    border-left: 5px solid #3498db;
}

.stat-card.waiting {
    border-left: 5px solid #f39c12;
}

.stat-card.repairing {
    border-left: 5px solid #e74c3c;
}

.stat-card.completed {
    border-left: 5px solid #2ecc71;
}

.stat-card.revenue {
    border-left: 5px solid #9b59b6;
}

.stat-card .stat-icon {
    font-size: 2.5em;
}

.stat-content h3 {
    margin: 0;
    font-size: 2em;
    color: #2c3e50;
}

.stat-content p {
    margin: 5px 0 0 0;
    color: #7f8c8d;
    font-size: 0.9em;
}

.stat-content small {
    color: #95a5a6;
    font-size: 0.8em;
}

/* Sections du dashboard */
.dashboard-sections {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 30px;
    margin-bottom: 30px;
}

@media (max-width: 1200px) {
    .dashboard-sections {
        grid-template-columns: 1fr;
    }
}

.section {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
}

.section-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 20px;
    padding-bottom: 15px;
    border-bottom: 2px solid #f1f2f6;
}

.section-header h2 {
    margin: 0;
    font-size: 1.5em;
    color: #2c3e50;
}

.badge {
    background: #3498db;
    color: white;
    padding: 5px 15px;
    border-radius: 20px;
    font-size: 0.9em;
}

/* Listes */
.cars-list, .repairs-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.car-card, .repair-card {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    border-left: 4px solid #3498db;
}

.car-header, .repair-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
}

.car-header h4, .repair-header h4 {
    margin: 0;
    color: #2c3e50;
}

.license-plate {
    background: #2c3e50;
    color: white;
    padding: 3px 10px;
    border-radius: 4px;
    font-family: monospace;
    font-weight: bold;
}

.car-info p, .repair-info p {
    margin: 5px 0;
    color: #555;
    font-size: 0.95em;
}

.car-problems, .progress-details {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
    margin-top: 10px;
}

.problem-tag, .intervention-tag {
    background: #e3f2fd;
    color: #1976d2;
    padding: 4px 10px;
    border-radius: 15px;
    font-size: 0.85em;
}

/* Barre de progression */
.progress-container {
    position: relative;
    width: 100px;
    height: 20px;
    background: #ecf0f1;
    border-radius: 10px;
    overflow: hidden;
}

.progress-bar {
    position: absolute;
    height: 100%;
    background: linear-gradient(90deg, #2ecc71, #27ae60);
    transition: width 0.5s ease;
}

.progress-text {
    position: absolute;
    width: 100%;
    text-align: center;
    font-size: 0.8em;
    font-weight: bold;
    color: #2c3e50;
    line-height: 20px;
}

/* Types de réparation */
.types-grid {
    display: grid;
    grid-template-columns: repeat(auto-fill, minmax(250px, 1fr));
    gap: 15px;
}

.type-card {
    background: #f8f9fa;
    padding: 20px;
    border-radius: 10px;
    border: 1px solid #e9ecef;
}

.type-card h4 {
    margin: 0 0 10px 0;
    color: #2c3e50;
}

.type-price {
    font-size: 1.2em;
    font-weight: bold;
    color: #27ae60;
    margin: 10px 0;
}

.type-desc {
    color: #7f8c8d;
    font-size: 0.9em;
    margin: 10px 0;
}

.type-meta {
    display: flex;
    gap: 10px;
    margin-top: 15px;
}

.meta-tag {
    background: #e9ecef;
    padding: 3px 10px;
    border-radius: 12px;
    font-size: 0.8em;
    color: #6c757d;
}

.meta-tag.easy {
    background: #d4edda;
    color: #155724;
}

.meta-tag.medium {
    background: #fff3cd;
    color: #856404;
}

.meta-tag.hard {
    background: #f8d7da;
    color: #721c24;
}

/* Information système */
.system-info {
    background: white;
    padding: 25px;
    border-radius: 12px;
    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
}

.system-info h3 {
    margin: 0 0 20px 0;
    color: #2c3e50;
}

.info-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(250px, 1fr));
    gap: 15px;
}

.info-item {
    display: flex;
    justify-content: space-between;
    padding: 10px 0;
    border-bottom: 1px solid #f1f2f6;
}

.info-label {
    color: #7f8c8d;
    font-weight: 500;
}

.info-value {
    color: #2c3e50;
    font-weight: 600;
}

.info-value.connected {
    color: #27ae60;
}

/* États vides */
.empty-state {
    text-align: center;
    padding: 40px 20px;
    color: #95a5a6;
    font-style: italic;
}

/* Chargement et erreurs */
.loading-overlay {
    position: fixed;
    top: 0;
    left: 0;
    right: 0;
    bottom: 0;
    background: rgba(255, 255, 255, 0.9);
    display: flex;
    flex-direction: column;
    justify-content: center;
    align-items: center;
    z-index: 1000;
}

.spinner {
    border: 4px solid #f3f3f3;
    border-top: 4px solid #3498db;
    border-radius: 50%;
    width: 50px;
    height: 50px;
    animation: spin 1s linear infinite;
    margin-bottom: 20px;
}

@keyframes spin {
    0% { transform: rotate(0deg); }
    100% { transform: rotate(360deg); }
}

.error-message {
    background: #f8d7da;
    color: #721c24;
    padding: 20px;
    border-radius: 8px;
    margin: 20px 0;
    text-align: center;
}

.retry-btn {
    background: #e74c3c;
    color: white;
    border: none;
    padding: 10px 20px;
    border-radius: 5px;
    cursor: pointer;
    margin-top: 10px;
}

.retry-btn:hover {
    background: #c0392b;
}
</style>