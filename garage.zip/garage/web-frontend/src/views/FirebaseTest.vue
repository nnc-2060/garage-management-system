<template>
  <div class="firebase-test">
    <h1>🧪 Test Firebase Connection</h1>
    
    <div class="test-section">
      <button @click="testConnection" :disabled="testing">
        {{ testing ? 'Test en cours...' : 'Tester la connexion Firebase' }}
      </button>
      
      <div v-if="result" class="result">
        <h3>Résultat :</h3>
        <pre>{{ formattedResult }}</pre>
      </div>
      
      <div v-if="error" class="error">
        <h3>Erreur :</h3>
        <p>{{ error }}</p>
      </div>
    </div>
    
    <div class="info">
      <p><strong>URL API :</strong> {{ apiUrl }}</p>
      <p><strong>Backend Laravel :</strong> http://localhost:8000</p>
      <p><strong>Frontend Vue :</strong> http://localhost:5173</p>
    </div>
  </div>
</template>

<script>
import api from '../services/api.js'

export default {
  name: 'FirebaseTest',
  data() {
    return {
      testing: false,
      result: null,
      error: null,
      apiUrl: import.meta.env.VUE_APP_API_URL || 'http://localhost:8000/api'
    }
  },
  computed: {
    formattedResult() {
      return JSON.stringify(this.result, null, 2)
    }
  },
  methods: {
    async testConnection() {
      this.testing = true
      this.result = null
      this.error = null
      
      try {
        const response = await api.get('/firebase/test')
        this.result = response.data
      } catch (error) {
        this.error = error.message
        console.error('Erreur détaillée:', error)
      } finally {
        this.testing = false
      }
    }
  }
}
</script>

<style scoped>
.firebase-test {
  padding: 40px;
  max-width: 800px;
  margin: 0 auto;
}

.test-section {
  background: #f5f5f5;
  padding: 30px;
  border-radius: 10px;
  margin: 30px 0;
}

button {
  background: #3498db;
  color: white;
  border: none;
  padding: 12px 24px;
  border-radius: 5px;
  cursor: pointer;
  font-size: 16px;
  margin-bottom: 20px;
}

button:hover:not(:disabled) {
  background: #2980b9;
}

button:disabled {
  opacity: 0.6;
  cursor: not-allowed;
}

.result, .error {
  margin-top: 20px;
  padding: 20px;
  border-radius: 5px;
  text-align: left;
}

.result {
  background: #d4edda;
  color: #155724;
  border: 1px solid #c3e6cb;
}

.error {
  background: #f8d7da;
  color: #721c24;
  border: 1px solid #f5c6cb;
}

pre {
  background: white;
  padding: 15px;
  border-radius: 5px;
  overflow-x: auto;
  font-family: 'Courier New', monospace;
}

.info {
  background: #e8f4fc;
  padding: 20px;
  border-radius: 5px;
  margin-top: 20px;
}

.info p {
  margin: 5px 0;
  font-family: monospace;
}
</style>