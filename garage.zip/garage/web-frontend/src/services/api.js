// src/services/api.js
import axios from 'axios'

const API_URL = import.meta.env.VUE_APP_API_URL || 'http://localhost:8000/api'

const api = axios.create({
  baseURL: API_URL,
  headers: {
    'Content-Type': 'application/json',
    'Accept': 'application/json'
  },
  timeout: 10000
})

// Intercepteur pour les erreurs
api.interceptors.response.use(
  response => response,
  error => {
    console.error('API Error:', {
      message: error.message,
      response: error.response?.data,
      status: error.response?.status,
      url: error.config?.url
    })
    
    // Message d'erreur plus clair
    if (error.code === 'ECONNABORTED') {
      error.message = 'Timeout: Le serveur ne répond pas'
    } else if (error.response) {
      // Erreur HTTP (4xx, 5xx)
      error.message = `Erreur ${error.response.status}: ${error.response.data?.message || 'Erreur serveur'}`
    } else if (error.request) {
      // Pas de réponse du serveur
      error.message = 'Pas de réponse du serveur. Vérifiez que le backend est démarré.'
    }
    
    return Promise.reject(error)
  }
)

export default api