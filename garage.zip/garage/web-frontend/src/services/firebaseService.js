// frontend-web/src/services/firebaseService.js
import api from './api';

export default {
    // Test de connexion
    async testConnection() {
        try {
            const response = await api.get('/firebase/test');
            return response.data;
        } catch (error) {
            throw new Error(`Erreur de connexion Firebase: ${error.message}`);
        }
    },

    // Dashboard complet
    async getDashboard() {
        try {
            const response = await api.get('/firebase/dashboard');
            return response.data;
        } catch (error) {
            throw new Error(`Erreur de chargement du dashboard: ${error.message}`);
        }
    },

    // Récupérer les statistiques
    async getStatistics() {
        try {
            const response = await api.get('/firebase/statistics');
            return response.data;
        } catch (error) {
            throw new Error(`Erreur de chargement des statistiques: ${error.message}`);
        }
    },

    // Récupérer les voitures en attente
    async getWaitingCars() {
        try {
            const response = await api.get('/firebase/waiting-cars');
            return response.data;
        } catch (error) {
            throw new Error(`Erreur de chargement des voitures: ${error.message}`);
        }
    },

    // Récupérer les réparations actives
    async getActiveRepairs() {
        try {
            const response = await api.get('/firebase/active-repairs');
            return response.data;
        } catch (error) {
            throw new Error(`Erreur de chargement des réparations: ${error.message}`);
        }
    }
};