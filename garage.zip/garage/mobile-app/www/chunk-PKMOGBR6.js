import{a,b}from"./chunk-MDMZPGPE.js";import"./chunk-DJZEU2VU.js";export{a as GESTURE_CONTROLLER,b as createGesture};
