import { Component, inject } from '@angular/core';
import { IonApp, IonRouterOutlet } from '@ionic/angular/standalone';
import { FirebaseService } from './services/firebase.service';
import { addIcons } from 'ionicons';
import {
  logOutOutline,
  logInOutline,
  sendOutline,
  documentTextOutline,
  hardwareChipOutline,
  personOutline,
  trashOutline,
  constructOutline,
  addOutline,
  createOutline,
  keyOutline,
  headsetOutline,
  checkmarkCircle,
  cog,
  ellipseOutline,
  helpCircleOutline
} from 'ionicons/icons';

@Component({
  selector: 'app-root',
  template: `
    <ion-app>
      <ion-router-outlet></ion-router-outlet>
    </ion-app>
  `,
  standalone: true,
  imports: [IonApp, IonRouterOutlet]
})
export class AppComponent {
  private firebaseService = inject(FirebaseService);

  constructor() {
    this.firebaseService.initPushNotifications();
    addIcons({
      logOutOutline,
      logInOutline,
      sendOutline,
      documentTextOutline,
      hardwareChipOutline,
      personOutline,
      trashOutline,
      constructOutline,
      addOutline,
      createOutline,
      keyOutline,
      headsetOutline,
      checkmarkCircle,
      cog,
      ellipseOutline,
      helpCircleOutline
    });
  }
}