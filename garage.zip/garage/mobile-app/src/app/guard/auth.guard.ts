import { inject } from '@angular/core';
import { Router } from '@angular/router';
import { Auth, authState } from '@angular/fire/auth';
import { CanActivateFn } from '@angular/router';
import { Observable } from 'rxjs';
import { map, take } from 'rxjs/operators';

// Fonction de garde pour la nouvelle syntaxe de garde d'Angular
export const AuthGuard: CanActivateFn = (route, state) => {
  const auth = inject(Auth);
  const router = inject(Router);

  return authState(auth).pipe(
    take(1),
    map(user => {
      if (user) {
        // L'utilisateur est connecté, autorise l'accès
        return true;
      } else {
        // L'utilisateur n'est pas connecté, redirige vers la page de login
        router.navigate(['/login']);
        return false;
      }
    })
  );
};