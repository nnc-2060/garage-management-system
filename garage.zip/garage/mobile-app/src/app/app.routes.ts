import { Routes } from '@angular/router';
import { AuthGuard } from './guard/auth.guard'; // Importez AuthGuard

export const routes: Routes = [
  {
    path: 'home',
    loadComponent: () => import('./home/home.page').then((m) => m.default), // Use m.default for default export
    canActivate: [AuthGuard] // Applique AuthGuard ici
  },
  {
    path: 'login',
    loadComponent: () => import('./pages/login/login.page').then(m => m.LoginPage)
  },
  {
    path: 'register',
    loadComponent: () => import('./pages/register/register.page').then(m => m.RegisterPage)
  },
  {
    path: 'profile',
    loadComponent: () => import('./pages/profile/profile.page').then(m => m.ProfilePage),
    canActivate: [AuthGuard] // Applique AuthGuard
  },
  {
    path: 'repairs',
    loadComponent: () => import('./pages/repairs/repairs.page').then(m => m.RepairsPage), // Utilise m.RepairsPage pour la classe nommée
    canActivate: [AuthGuard] // Applique AuthGuard
  },
  {
    path: 'admin-pannes',
    loadComponent: () => import('./pages/adminPannes/adminPannes.page').then(m => m.AdminPannesPage),
    canActivate: [AuthGuard] // Applique AuthGuard
  },
  {
    path: 'repair-detail/:id',
    loadComponent: () => import('./pages/repair-detail/repair-detail.page').then( m => m.RepairDetailPage),
    canActivate: [AuthGuard] // Applique AuthGuard
  },
  {
    path: 'payment/:id',
    loadComponent: () => import('./pages/payment/payment.page').then( m => m.PaymentPage),
    canActivate: [AuthGuard] // Applique AuthGuard
  },
  {
    path: '',
    redirectTo: 'login', // Redirige vers la page de login par défaut
    pathMatch: 'full',
  },
];
