import { Component, OnInit, inject, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '@angular/fire/auth';
import { Subscription } from 'rxjs';
import { 
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonInput,
  IonButton,
  IonLabel,
  IonItem,
  IonList,
  IonCard,
  IonCardContent,
  IonIcon,
  IonCardHeader,
  IonCardTitle,
  IonText,
  IonButtons,
  IonGrid,
  IonRow,
  IonCol,
  IonTextarea,
  IonSelect,
  IonSelectOption,
  IonSpinner,
  IonItemGroup,
  IonItemDivider,
  IonCheckbox
} from '@ionic/angular/standalone';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FirebaseService } from '../services/firebase.service';
import { Panne } from '../models/panne.model';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    ReactiveFormsModule, // Added ReactiveFormsModule
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonInput,
    IonButton,
    IonLabel,
    IonItem,
    IonList,
    IonCard,
    IonCardContent,
    IonIcon,
    IonCardHeader,
    IonCardTitle,
    IonText,
    IonButtons,
    IonGrid,
    IonRow,
    IonCol,
    IonTextarea,
    IonSelect,
    IonSelectOption,
    IonSpinner,
    IonItemGroup,
    IonItemDivider,
    IonCheckbox
  ]
})
export class HomePage implements OnInit, OnDestroy {
  // Données du formulaire
  carModel = '';
  carYear?: number;
  carLicensePlate = '';
  additionalNotes = ''; // Remplacer panneDescription
  priority: 'low' | 'medium' | 'high' = 'medium';

  // Données des interventions
  interventions: any[] = [];
  selectedInterventions: { [key: string]: boolean } = {};
  totalPrice = 0;

  // Statut de la page
  statusMessage = '';
  isLoading = false;

  // Données utilisateur
  isLoggedIn = false;
  userEmail = '';
  userName = '';
  userStats: any = {};
  
  private authSubscription!: Subscription;

  // Services
  private firebaseService = inject(FirebaseService);
  private router = inject(Router);

  ngOnInit() {
    this.checkAuth();
    this.loadInterventions();
  }

  ngOnDestroy() {
    if (this.authSubscription) {
      this.authSubscription.unsubscribe();
    }
  }

  private checkAuth() {
    this.authSubscription = this.firebaseService.getCurrentUser().subscribe({
      next: async (user: User | null) => {
        this.isLoggedIn = !!user;
        this.userEmail = user?.email || '';
        if (user) {
          const profile = await this.firebaseService.getUserProfile(user.uid);
          this.userName = profile?.displayName || user.displayName || 'Utilisateur';
        }
      },
      error: (err) => {
        console.error('Erreur auth:', err);
        this.isLoggedIn = false;
      }
    });
  }

  private async loadInterventions() {
    try {
      this.interventions = await this.firebaseService.getInterventions();
      console.log('Interventions chargées:', this.interventions);
    } catch (error) {
      this.showMessage('Erreur de chargement des interventions');
      console.error(error);
    }
  }

  onInterventionChange() {
    this.totalPrice = this.interventions
      .filter(item => this.selectedInterventions[item.id])
      .reduce((sum, item) => sum + item.price, 0);
  }

  async sendPanne() {
    const selectedItems = this.interventions.filter(item => this.selectedInterventions[item.id]);

    if (!this.carModel.trim()) {
      this.showMessage('Veuillez spécifier le modèle de la voiture.');
      return;
    }

    if (selectedItems.length === 0) {
      this.showMessage('Veuillez sélectionner au moins une intervention.');
      return;
    }

    if (!this.isLoggedIn) {
      this.showMessage('Veuillez vous connecter d\'abord');
      this.goToLogin();
      return;
    }

    this.isLoading = true;

    const panneData = {
      description: this.additionalNotes, // Le champ description peut servir de notes additionnelles
      timestamp: new Date(),
      status: 'en_attente' as const,
      clientName: this.userName,
      carModel: this.carModel,
      carYear: this.carYear,
      carLicensePlate: this.carLicensePlate,
      priority: this.priority,
      totalPrice: this.totalPrice
    };

    try {
      // @ts-ignore
      const result = await this.firebaseService.sendPanne(panneData, selectedItems);
      
      if (result.success) {
        this.showMessage(`✅ Panne signalée avec succès !`);
        this.resetForm();
      } else {
        this.showMessage(`❌ Erreur: ${result.error}`);
      }
    } catch (error: any) {
      this.showMessage(`Erreur: ${error.message}`);
    } finally {
      this.isLoading = false;
    }
  }

  private showMessage(message: string) {
    this.statusMessage = message;
    setTimeout(() => this.statusMessage = '', 5000);
  }

  private resetForm() {
    this.carModel = '';
    this.carYear = undefined;
    this.carLicensePlate = '';
    this.additionalNotes = '';
    this.priority = 'medium';
    this.selectedInterventions = {};
    this.totalPrice = 0;
  }

  // ... (le reste des méthodes de navigation et autres restent identiques)
  
  // Navigation
  goToLogin() { this.router.navigate(['/login']); }
  goToRegister() { this.router.navigate(['/register']); }
  goToRepairs() { this.router.navigate(['/repairs']); }
  goToProfile() { this.router.navigate(['/profile']); }
  goToAdminPannes() { this.router.navigate(['/admin-pannes']); }

  async logout() {
    try {
      await this.firebaseService.logout();
      this.isLoggedIn = false;
      this.userEmail = '';
      this.userName = '';
      this.showMessage('Déconnexion réussie');
      this.router.navigate(['/login']);
    } catch (error) {
      this.showMessage('Erreur de déconnexion');
    }
  }

  testConnection() {
    this.firebaseService.testFirebaseConnection();
    this.showMessage('Test Firebase en cours...');
  }

  clearLocalData() {
    localStorage.removeItem('last_panne');
    if ('indexedDB' in window) {
      indexedDB.deleteDatabase('GarageDB');
    }
    this.showMessage('Données locales effacées');
  }

  // Getter pour simplifier la logique du template pour le bouton de soumission
  get isSubmitDisabled(): boolean {
    return !this.isLoggedIn || this.isLoading;
  }
}
export default HomePage;