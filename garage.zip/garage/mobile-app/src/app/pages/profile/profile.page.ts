import { Component, OnInit, inject } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { 
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  // IonButton,  // RETIRER si non utilisé
  IonLabel,
  IonItem,
  IonList,
  IonCard,
  IonCardContent,
  IonIcon,
  IonCardHeader,
  IonCardTitle,
  IonText,
  IonButtons,
  IonBackButton,
  IonAvatar
} from '@ionic/angular/standalone';
import { FirebaseService } from '../../services/firebase.service';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.page.html',
  styleUrls: ['./profile.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    // IonButton,  // RETIRER si non utilisé
    IonLabel,
    IonItem,
    IonList,
    IonCard,
    IonCardContent,
    IonIcon,
    IonCardHeader,
    IonCardTitle,
    IonText,
    IonButtons,
    IonBackButton,
    IonAvatar
  ]
})
export class ProfilePage implements OnInit {
  userEmail = '';
  userName = 'Utilisateur';
  userSince = new Date().toLocaleDateString();

  private firebaseService = inject(FirebaseService);
  private router = inject(Router);

  ngOnInit() {
    this.loadUserData();
  }

  loadUserData() {
    this.firebaseService.getCurrentUser().subscribe({
      next: (user) => {
        if (user) {
          this.userEmail = user.email || '';
          this.userName = user.displayName || 'Utilisateur';
        }
      },
      error: (err) => {
        console.error('Erreur chargement profil:', err);
      }
    });
  }

  goToHome() {
    this.router.navigate(['/']);
  }

  editProfile() {
    console.log('Édition du profil');
  }

  changePassword() {
    console.log('Changement de mot de passe');
  }

  contactSupport() {
    console.log('Contact support');
  }
}