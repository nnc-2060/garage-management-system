import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router'; // Added Router
import { Observable, Subscription } from 'rxjs';
import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonBackButton,
  IonButtons,
  IonSpinner,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonList,
  IonItem,
  IonLabel,
  IonText,
  IonIcon,
  IonBadge,
  IonProgressBar,
  IonFooter,
  IonButton // Added IonButton
} from '@ionic/angular/standalone';
import { FirebaseService } from '../../services/firebase.service';
import { Panne } from '../../models/panne.model';

@Component({
  selector: 'app-repair-detail',
  templateUrl: './repair-detail.page.html',
  styleUrls: ['./repair-detail.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonBackButton,
    IonButtons,
    IonSpinner,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonList,
    IonItem,
    IonLabel,
    IonText,
    IonIcon,
    IonBadge,
    IonProgressBar,
    IonFooter,
    IonButton
  ]
})
export class RepairDetailPage implements OnInit, OnDestroy {
  public panne: Panne | null = null;
  private route = inject(ActivatedRoute);
  private router = inject(Router);
  private firebaseService = inject(FirebaseService);
  // private panneSubscription?: Subscription; // Non nécessaire avec getPanneById

  async ngOnInit() { // Rendre ngOnInit asynchrone
    const panneId = this.route.snapshot.paramMap.get('id');
    if (panneId) {
      this.panne = await this.firebaseService.getPanneById(panneId); // Utiliser getPanneById
    }
  }

  ngOnDestroy() {
    // Plus besoin de se désabonner si on utilise getPanneById
  }

  getStatusColor(status: string): string {
    switch(status) {
      case 'terminée':
      case 'completed':
        return 'success';
      case 'payée': // Nouveau cas pour le statut payé
        return 'tertiary'; // Ou une autre couleur appropriée
      case 'en_cours':
      case 'in_progress':
        return 'warning';
      case 'en_attente':
      case 'pending':
        return 'medium';
      case 'annulée':
        return 'danger';
      default:
        return 'primary';
    }
  }

  getTaskStatusIcon(status: string): string {
    switch(status) {
      case 'completed': return 'checkmark-circle';
      case 'in_progress': return 'cog';
      case 'pending': return 'ellipse-outline';
      default: return 'help-circle-outline';
    }
  }

  goToPayment(panneId: string | undefined) {
    if (!panneId) {
      console.error('ID de la panne manquant, impossible de procéder au paiement.');
      return;
    }
    this.router.navigate(['/payment', panneId]);
  }
}
