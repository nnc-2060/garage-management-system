import { Component, OnInit, inject, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import {
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButton,
  IonLabel,
  IonItem,
  IonList,
  IonCard,
  IonCardContent,
  IonIcon,
  IonCardHeader,
  IonCardTitle,
  IonButtons,
  IonBackButton,
  IonBadge,
  IonChip,
  IonSpinner
} from '@ionic/angular/standalone';
import { FirebaseService } from '../../services/firebase.service';
import { Panne } from '../../models/panne.model';

@Component({
  selector: 'app-repairs',
  templateUrl: './repairs.page.html',
  styleUrls: ['./repairs.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonButton,
    IonLabel,
    IonItem,
    IonList,
    IonCard,
    IonCardContent,
    IonIcon,
    IonCardHeader,
    IonCardTitle,
    IonButtons,
    IonBackButton,
    IonBadge,
    IonChip,
    IonSpinner
  ]
})
export class RepairsPage implements OnInit, OnDestroy {
  repairs: Panne[] = [];
  filteredRepairs: Panne[] = [];
  activeFilter: string = 'all';
  isLoading = true;

  totalRepairs: number = 0;
  completedRepairs: number = 0;
  inProgressRepairs: number = 0;
  totalSpent: number = 0;

  private authSubscription!: Subscription;
  private firebaseService = inject(FirebaseService);
  private router = inject(Router);

  private repairsSubscription!: Subscription;

  ngOnInit() {
    // Pour charger les données depuis Firebase
    this.loadRepairsRealtime(); 
  }

  ngOnDestroy() {
    if (this.authSubscription) this.authSubscription.unsubscribe();
    if (this.repairsSubscription) this.repairsSubscription.unsubscribe();
  }

  loadRepairsRealtime() {
    this.isLoading = true;

    this.authSubscription = this.firebaseService.getCurrentUser().subscribe(user => {
      if (user) {
        if (this.repairsSubscription) this.repairsSubscription.unsubscribe();

        this.repairsSubscription = this.firebaseService.getPannesRealtime(user.uid).subscribe(pannes => {
          this.repairs = pannes;
          this.calculateStats();
          this.filterRepairs(this.activeFilter); // Réappliquer le filtre actif
          this.isLoading = false;
        });
      } else {
        this.isLoading = false;
        this.repairs = [];
        this.calculateStats();
        this.filterRepairs('all');
      }
    });
  }

  calculateStats() {
    this.totalRepairs = this.repairs.length;
    this.completedRepairs = this.repairs.filter(r => r.status === 'terminée' || r.status === 'payée').length; // Inclure 'payée' dans les terminées
    this.inProgressRepairs = this.repairs.filter(r => 
      r.status === 'en_attente' || r.status === 'en_cours'
    ).length;
    this.totalSpent = this.repairs.reduce((sum, r) => sum + r.totalPrice, 0);
  }

  filterRepairs(status: string) {
    this.activeFilter = status;
    
    if (status === 'all') {
      this.filteredRepairs = this.repairs;
    } else if (status === 'terminée') { // Modifié pour inclure 'payée' dans le filtre 'terminée' si désiré
      this.filteredRepairs = this.repairs.filter(repair => repair.status === 'terminée' || repair.status === 'payée');
    } else {
      this.filteredRepairs = this.repairs.filter(repair => repair.status === status);
    }
  }

  getStatusText(status: string): string {
    switch(status) {
      case 'en_attente': return 'En attente';
      case 'en_cours': return 'En cours';
      case 'terminée': return 'Terminée';
      case 'payée': return 'Payée'; 
      case 'annulée': return 'Annulée';
      default: return status;
    }
  }

  getStatusColor(status: string): string {
    switch(status) {
      case 'terminée': return 'success';
      case 'payée': return 'tertiary'; 
      case 'en_cours': return 'warning';
      case 'en_attente': return 'medium';
      case 'annulée': return 'danger';
      default: return 'medium';
    }
  }

  formatDate(timestamp: any): string {
    if (!timestamp) return 'N/A';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleDateString('fr-FR');
  }

  viewRepairDetails(repair: Panne) {
    if (repair.id) {
      this.router.navigate(['/repair-detail', repair.id]);
    } else {
      console.error('Erreur: Impossible de voir les détails car l\'ID de la réparation est manquant.');
    }
  }

  goToHome() {
    this.router.navigate(['/']);
  }

  addNewRepair() {
    this.router.navigate(['/']);
  }

  goToPayment(id: string | undefined) {
    if (id) {
      this.router.navigate(['/payment', id]);
    } else {
      console.error('Erreur: Impossible de procéder au paiement car l\'ID de la réparation est manquant.');
    }
  }
}
export default RepairsPage; // Ajoute l'exportation par défaut
