import { Component, inject, OnInit } from '@angular/core';
import { Router } from '@angular/router'; // RETIRER RouterLink
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { 
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonInput,
  IonButton,
  IonLabel,
  IonItem,
  IonList,
  IonCard,
  IonCardContent,
  // IonIcon,  // RETIRER si non utilisé
  IonCardHeader,
  IonCardTitle,
  IonText,
  IonButtons,
  IonBackButton,
  IonSpinner
} from '@ionic/angular/standalone';
import { FirebaseService } from '../../services/firebase.service';
import { Subscription } from 'rxjs'; // Importation de Subscription

@Component({
  selector: 'app-login',
  templateUrl: './login.page.html',
  styleUrls: ['./login.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    // RETIRER RouterLink
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonInput,
    IonButton,
    IonLabel,
    IonItem,
    IonList,
    IonCard,
    IonCardContent,
    // IonIcon,  // RETIRER si non utilisé
    IonCardHeader,
    IonCardTitle,
    IonText,
    IonButtons,
    IonBackButton,
    IonSpinner
  ]
})
export class LoginPage implements OnInit { // Implémente OnInit
  email = '';
  password = '';
  errorMessage = '';
  isLoading = false;

  private firebaseService = inject(FirebaseService);
  private router = inject(Router);
  private authSubscription: Subscription | undefined; // Pour gérer l'abonnement

  ngOnInit() {
    // Vérifie si l'utilisateur est déjà connecté au chargement de la page de login
    this.authSubscription = this.firebaseService.getCurrentUser().subscribe(user => {
      if (user) {
        // Si un utilisateur est connecté, redirige vers la page d'accueil
        this.router.navigate(['/home']);
      }
    });
  }

  ngOnDestroy() {
    // Désabonne-toi pour éviter les fuites de mémoire
    if (this.authSubscription) {
      this.authSubscription.unsubscribe();
    }
  }

  async login() {
    if (!this.email || !this.password) {
      this.errorMessage = 'Veuillez remplir tous les champs';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    const result = await this.firebaseService.login(this.email, this.password);
    
    if (result.success) {
      // Redirige vers la page d'accueil après une connexion réussie
      this.router.navigate(['/home']);
    } else {
      this.errorMessage = result.error || 'Erreur de connexion';
    }
    
    this.isLoading = false;
  }

  goToRegister() {
    this.router.navigate(['/register']);
  }

  goToHome() {
    this.router.navigate(['/home']); // Utilise '/home' pour la redirection
  }

  async resetPassword() {
    if (!this.email) {
      this.errorMessage = 'Veuillez entrer votre email';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    const result = await this.firebaseService.resetPassword(this.email);
    
    if (result.success) {
      this.errorMessage = '✅ Email de réinitialisation envoyé !';
    } else {
      this.errorMessage = result.error || 'Erreur lors de l\'envoi';
    }
    
    this.isLoading = false;
  }
}