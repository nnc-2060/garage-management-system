import { Component, OnInit, OnDestroy, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { Subscription } from 'rxjs';
import { 
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonBackButton,
  IonButtons,
  IonSpinner,
  IonCard,
  IonCardHeader,
  IonCardTitle,
  IonCardContent,
  IonItem,
  IonLabel,
  IonText,
  IonButton,
  IonIcon
} from '@ionic/angular/standalone';
import { FirebaseService } from '../../services/firebase.service';
import { Panne } from '../../models/panne.model';

@Component({
  selector: 'app-payment',
  templateUrl: './payment.page.html',
  styleUrls: ['./payment.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonBackButton,
    IonButtons,
    IonSpinner,
    IonCard,
    IonCardHeader,
    IonCardTitle,
    IonCardContent,
    IonItem,
    IonLabel,
    IonText,
    IonButton,
    IonIcon
  ]
})
export class PaymentPage implements OnInit, OnDestroy {
  public panne: Panne | null = null;
  public isLoading = false;
  private panneId: string | null = null;
  // private panneSubscription?: Subscription; // Non nécessaire avec getPanneById
  
  private route = inject(ActivatedRoute);
  private router = inject(Router); // Fix: inject(Router) already correct
  private firebaseService = inject(FirebaseService);

  async ngOnInit() { // Rendre ngOnInit asynchrone
    this.panneId = this.route.snapshot.paramMap.get('id');
    if (this.panneId) {
      this.panne = await this.firebaseService.getPanneById(this.panneId); // Utiliser getPanneById
    }
  }

  ngOnDestroy() {
    // Plus besoin de se désabonner si on utilise getPanneById
  }

  async simulatePayment() {
    if (!this.panneId) return;

    this.isLoading = true;
    
    // Simuler un appel à une passerelle de paiement
    await new Promise(resolve => setTimeout(resolve, 1500));

    // Mettre à jour le statut dans Firebase
    const success = await this.firebaseService.updatePanneStatus(this.panneId, 'payée');

    this.isLoading = false;

    if (success) {
      // Rediriger vers la page de détail qui affichera le nouveau statut
      this.router.navigate(['/repair-detail', this.panneId]);
    } else {
      // Gérer l'erreur (afficher une alerte, par exemple)
      console.error('Échec de la mise à jour du statut après paiement.');
    }
  }
}
