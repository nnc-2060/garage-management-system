import { Injectable, inject } from '@angular/core';
import { Observable, from, map } from 'rxjs';
import { GodotService } from './godot.service';
import { Capacitor } from '@capacitor/core';
import { PushNotifications } from '@capacitor/push-notifications';
import { 
  Firestore, 
  collection, 
  addDoc, 
  doc, 
  setDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  Timestamp,
  DocumentData,
  onSnapshot
} from '@angular/fire/firestore';
import { 
  Auth, 
  authState, 
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail,
  User,
  onAuthStateChanged
} from '@angular/fire/auth';
import { Panne } from '../models/panne.model';
import { UserProfile } from '../models/userProfile.model';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  private firestore = inject(Firestore);
  private auth = inject(Auth);
  private godotService = inject(GodotService);

  // ============ AUTHENTIFICATION ============
  getInterventions(): Promise<any[]> {
    const interventionsCollection = collection(this.firestore, 'interventions');
    return getDocs(interventionsCollection).then(snapshot => 
      snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }))
    );
  }

  getCurrentUser(): Observable<User | null> {
    return authState(this.auth);
  }

  async login(email: string, password: string): Promise<{success: boolean, error?: string}> {
    try {
      await signInWithEmailAndPassword(this.auth, email, password);
      return { success: true };
    } catch (error: any) {
      console.error('Erreur login:', error);
      return { success: false, error: this.getAuthErrorMessage(error) };
    }
  }

  async register(email: string, password: string, fullName?: string, phone?: string): Promise<{success: boolean, error?: string}> {
    try {
      const userCredential = await createUserWithEmailAndPassword(this.auth, email, password);
      
      if (fullName && userCredential.user) {
        await updateProfile(userCredential.user, { displayName: fullName });
      }
      
      await this.createUserProfile(userCredential.user, fullName, phone);
      return { success: true };
    } catch (error: any) {
      console.error('Erreur register:', error);
      return { success: false, error: this.getAuthErrorMessage(error) };
    }
  }

  async logout(): Promise<void> {
    try {
      await signOut(this.auth);
    } catch (error) {
      console.error('Erreur de déconnexion:', error);
      throw error;
    }
  }

  async resetPassword(email: string): Promise<{success: boolean, error?: string}> {
    try {
      await sendPasswordResetEmail(this.auth, email);
      return { success: true };
    } catch (error: any) {
      console.error('Erreur reset password:', error);
      return { success: false, error: this.getAuthErrorMessage(error) };
    }
  }

  // ============ GESTION DES UTILISATEURS ============
  private async createUserProfile(user: User, fullName?: string, phone?: string): Promise<void> {
    try {
      const userProfile: UserProfile = {
        uid: user.uid,
        email: user.email || '',
        displayName: fullName || user.displayName || '',
        phone: phone || '',
        address: '',
        createdAt: Timestamp.now(),
        role: 'client',
        isActive: true
      };

      const userDoc = doc(this.firestore, `users/${user.uid}`);
      await setDoc(userDoc, userProfile);
      console.log('✅ Profil utilisateur créé');
    } catch (error) {
      console.error('❌ Erreur création profil:', error);
    }
  }

  async getUserProfile(uid: string): Promise<UserProfile | null> {
    try {
      const userDoc = doc(this.firestore, `users/${uid}`);
      const docSnap = await getDoc(userDoc);
      
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as UserProfile;
      }
      return null;
    } catch (error) {
      console.error('Erreur récupération profil:', error);
      return null;
    }
  }

  async updateUserProfile(uid: string, data: Partial<UserProfile>): Promise<boolean> {
    try {
      const userDoc = doc(this.firestore, `users/${uid}`);
      await updateDoc(userDoc, {
        ...data,
        updatedAt: Timestamp.now()
      });
      return true;
    } catch (error) {
      console.error('Erreur mise à jour profil:', error);
      return false;
    }
  }

  // ============ GESTION DES PANNES (AVEC GODOT) ============
  async sendPanne(
    panneData: Omit<Panne, 'id' | 'createdAt' | 'updatedAt' | 'godotRepairs'>, 
    selectedInterventions: any[]
  ): Promise<{success: boolean, id?: string, error?: string, godotSuccess?: boolean}> {
    try {
      const user = this.auth.currentUser;
      if (!user) throw new Error('Utilisateur non connecté');
      if (selectedInterventions.length === 0) throw new Error('Veuillez sélectionner au moins une intervention.');

      // Use the totalPrice from panneData, as it's passed from the UI
      const finalTotalPrice = panneData.totalPrice; 

      // Formater les réparations pour Godot
      const godotRepairs = selectedInterventions.map(item => ({
        type: item.id,
        name: item.name,
        duration: item.duration_seconds,
        price: item.price,
        status: 'pending',
        progress: 0
      }));

      // 1. Créer la panne avec les bons calculs
      const panneToSave = {
        ...panneData,
        userId: user.uid,
        userEmail: user.email,
        status: 'en_attente',
        totalPrice: finalTotalPrice,
        laborCost: finalTotalPrice * 0.7, // 70% main d'œuvre - A ajuster si nécessaire
        partsCost: finalTotalPrice * 0.3, // 30% pièces - A ajuster si nécessaire
        timestamp: Timestamp.fromDate(new Date(panneData.timestamp)),
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
        technicianId: '',
        technicianName: '',
        startDate: null,
        endDate: null,
        parts: [],
        notes: '',
        // Champs Godot
        godotStatus: 'waiting',
        godotRepairs: godotRepairs,
        godotSlot: null,
        godotPosition: this.getRandomPosition(),
        godotCarColor: this.getRandomColor(),
        godotLastUpdate: Timestamp.now()
      };

      // 3. Sauvegarder dans Firestore
      const pannesCollection = collection(this.firestore, 'pannes');
      const docRef = await addDoc(pannesCollection, panneToSave);

      console.log('✅ Panne sauvegardée avec ID:', docRef.id);
      
      // Le reste de la logique pour Godot reste inchangé
      const panneComplete: Panne = {
        ...panneToSave,
        id: docRef.id,
        timestamp: panneToSave.timestamp.toDate(),
        createdAt: panneToSave.createdAt,
        updatedAt: panneToSave.updatedAt,
        godotLastUpdate: panneToSave.godotLastUpdate
      } as Panne;

      let godotSuccess = false;
      let godotCommandId = '';
      
      try {
        const godotResult = await this.godotService.sendPanneToGodot(panneComplete);
        godotSuccess = godotResult.success;
        if (godotSuccess) {
          console.log('🎮 Panne envoyée à Godot avec succès!');
          await updateDoc(docRef, { godotCommandId: godotResult.commandId || '' });
          this.setupGodotListener(docRef.id);
        } else {
          console.log('⚠️ Panne sauvegardée mais erreur avec Godot');
        }
      } catch (godotError) {
        console.error('⚠️ Erreur envoi Godot (non bloquant):', godotError);
      }

      return { 
        success: true, 
        id: docRef.id,
        godotSuccess: godotSuccess 
      };
    } catch (error: any) {
      console.error('❌ Erreur sauvegarde panne:', error);
      return { success: false, error: error.message };
    }
  }

  // Configurer l'écoute des réponses Godot
  private setupGodotListener(panneId: string) {
    // ... (le reste de la méthode reste identique)
    const unsubscribe = this.godotService.listenToGodotResponses(panneId, async (response) => {
      console.log('🔄 Réponse Godot reçue:', response.type);
      
      try {
        const panneDoc = doc(this.firestore, `pannes/${panneId}`);
        
        switch (response.type) {
          case 'REPAIR_STARTED':
            await updateDoc(panneDoc, {
              godotStatus: 'in_progress',
              godotSlot: response.data?.slot,
              status: 'en_cours',
              startDate: Timestamp.now(),
              godotMechanicId: response.data?.mechanicId,
              godotLastUpdate: Timestamp.now()
            });
            break;
            
          case 'REPAIR_PROGRESS':
            if (response.data?.repairs) {
              await updateDoc(panneDoc, {
                godotRepairs: response.data.repairs,
                godotLastUpdate: Timestamp.now()
              });
            }
            break;
            
          case 'REPAIR_COMPLETED':
            await updateDoc(panneDoc, {
              godotStatus: 'completed',
              status: 'terminée',
              endDate: Timestamp.now(),
              godotLastUpdate: Timestamp.now()
            });
            break;
            
          case 'PAYMENT_RECEIVED':
            await updateDoc(panneDoc, {
              godotStatus: 'paid',
              godotLastUpdate: Timestamp.now()
            });
            break;
        }
      } catch (error) {
        console.error('❌ Erreur mise à jour panne après réponse Godot:', error);
      }
    });
    return unsubscribe;
  }

  async getPannesByUser(userId: string): Promise<Panne[]> {
    try {
      const pannesCollection = collection(this.firestore, 'pannes');
      const q = query(
        pannesCollection, 
        where('userId', '==', userId),
        orderBy('createdAt', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      const pannes: Panne[] = [];
      
      querySnapshot.forEach(doc => {
        const data = doc.data();
        pannes.push({ 
          id: doc.id, 
          ...this.parsePanneData(data)
        });
      });
      
      return pannes;
    } catch (error) {
      console.error('Erreur récupération pannes:', error);
      return [];
    }
  }

  async getAllPannes(): Promise<Panne[]> {
    try {
      const pannesCollection = collection(this.firestore, 'pannes');
      const q = query(pannesCollection, orderBy('createdAt', 'desc'));
      
      const querySnapshot = await getDocs(q);
      const pannes: Panne[] = [];
      
      querySnapshot.forEach(doc => {
        const data = doc.data();
        pannes.push({ 
          id: doc.id, 
          ...this.parsePanneData(data)
        });
      });
      
      return pannes;
    } catch (error) {
      console.error('Erreur récupération toutes pannes:', error);
      return [];
    }
  }

  // Méthode utilitaire pour parser les données Firestore
  private parsePanneData(data: any): any {
    return {
      ...data,
      timestamp: data['timestamp']?.toDate() || new Date(),
      createdAt: data['createdAt']?.toDate() || new Date(),
      updatedAt: data['updatedAt']?.toDate() || new Date(),
      startDate: data['startDate']?.toDate() || null,
      endDate: data['endDate']?.toDate() || null,
      godotLastUpdate: data['godotLastUpdate']?.toDate() || null
    };
  }

  async updatePanneStatus(panneId: string, status: string, technicianId?: string, technicianName?: string): Promise<boolean> {
    try {
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      const updateData: any = { 
        status, 
        updatedAt: Timestamp.now() 
      };
      
      if (technicianId) {
        updateData.technicianId = technicianId;
      }
      if (technicianName) {
        updateData.technicianName = technicianName;
      }
      
      await updateDoc(panneDoc, updateData);
      return true;
    } catch (error) {
      console.error('Erreur mise à jour statut:', error);
      return false;
    }
  }

  async updatePanne(panneId: string, data: Partial<Panne>): Promise<boolean> {
    try {
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      await updateDoc(panneDoc, {
        ...data,
        updatedAt: Timestamp.now()
      });
      return true;
    } catch (error) {
      console.error('Erreur mise à jour panne:', error);
      return false;
    }
  }

  async deletePanne(panneId: string): Promise<boolean> {
    try {
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      await deleteDoc(panneDoc);
      return true;
    } catch (error) {
      console.error('Erreur suppression panne:', error);
      return false;
    }
  }

  async getPanneById(panneId: string): Promise<Panne | null> {
    try {
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      const docSnap = await getDoc(panneDoc);
      
      if (docSnap.exists()) {
        const data = docSnap.data();
        return { 
          id: docSnap.id, 
          ...this.parsePanneData(data)
        } as Panne;
      }
      return null;
    } catch (error) {
      console.error('Erreur récupération panne:', error);
      return null;
    }
  }

  // ============ GESTION GODOT ============
  async checkGodotStatus(): Promise<boolean> {
    return this.godotService.checkGodotStatus();
  }

  async sendActionToGodot(panneId: string, action: string, data?: any): Promise<boolean> {
    return this.godotService.sendActionToGodot(action, panneId, data);
  }

  async sendQuickAction(panneId: string, action: 'horn' | 'lights' | 'test'): Promise<boolean> {
    return this.godotService.sendQuickAction(panneId, action);
  }

  async forceGodotProcess(panneId: string): Promise<boolean> {
    return this.godotService.forceGodotProcess(panneId);
  }

  // Écouter toutes les réponses Godot (pour debug)
  listenToAllGodotResponses(callback: (response: any) => void) {
    return this.godotService.listenToAllGodotResponses(callback);
  }

  // ============ NOTIFICATIONS PUSH ============
  async initPushNotifications(): Promise<void> {
    if (!Capacitor.isNativePlatform()) {
      console.log('Les notifications Push ne sont pas disponibles sur le web.');
      return;
    }

    try {
      await PushNotifications.requestPermissions();
      await PushNotifications.register();

      PushNotifications.addListener('registration', async (token) => {
        console.log('Token de notification:', token.value);
        const user = this.auth.currentUser;
        if (user) {
          await this.updateUserProfile(user.uid, { pushToken: token.value });
          console.log('✅ Token de notification sauvegardé pour l\'utilisateur.');
        }
      });

      PushNotifications.addListener('registrationError', (error) => {
        console.error('Erreur d\'enregistrement des notifications:', error);
      });

      PushNotifications.addListener('pushNotificationReceived', (notification) => {
        console.log('Notification reçue:', notification);
        // Ici, vous pourriez afficher une alerte ou un toast si l'app est en premier plan
      });

      PushNotifications.addListener('pushNotificationActionPerformed', (notification) => {
        console.log('Action sur la notification:', notification);
        // Ici, vous pourriez naviguer vers une page spécifique, par exemple
        // this.router.navigate(['/repairs', notification.notification.data.repairId]);
      });
    } catch (error) {
      console.error('❌ Erreur initialisation notifications push:', error);
    }
  }

  // ============ STATISTIQUES ============
  async getStats(userId?: string): Promise<any> {
    try {
      const pannesCollection = collection(this.firestore, 'pannes');
      let q;
      
      if (userId) {
        q = query(pannesCollection, where('userId', '==', userId));
      } else {
        q = query(pannesCollection);
      }
      
      const querySnapshot = await getDocs(q);
      const stats = {
        total: 0,
        en_attente: 0,
        en_cours: 0,
        terminée: 0,
        annulée: 0,
        totalRevenue: 0,
        godotWaiting: 0,
        godotInProgress: 0,
        godotCompleted: 0
      };
      
      querySnapshot.forEach(doc => {
        const data = doc.data();
        stats.total++;
        
        // Statut général
        const status = data['status'];
        if (status && stats.hasOwnProperty(status)) {
          stats[status as keyof typeof stats] = (stats[status as keyof typeof stats] || 0) + 1;
        }
        
        // Statut Godot
        const godotStatus = data['godotStatus'];
        if (godotStatus) {
          const godotKey = `godot${godotStatus.charAt(0).toUpperCase() + godotStatus.slice(1)}` as keyof typeof stats;
          if (stats.hasOwnProperty(godotKey)) {
            stats[godotKey] = (stats[godotKey] || 0) + 1;
          }
        }
        
        // Revenue
        if (data['totalPrice']) {
          stats.totalRevenue += data['totalPrice'];
        }
      });
      
      return stats;
    } catch (error) {
      console.error('Erreur calcul stats:', error);
      return {};
    }
  }

  // ============ UTILITAIRES ============
  private getAuthErrorMessage(error: any): string {
    const errorCode = error.code;
    
    switch(errorCode) {
      case 'auth/user-not-found':
        return 'Utilisateur non trouvé';
      case 'auth/wrong-password':
        return 'Mot de passe incorrect';
      case 'auth/invalid-email':
        return 'Email invalide';
      case 'auth/email-already-in-use':
        return 'Cet email est déjà utilisé';
      case 'auth/weak-password':
        return 'Le mot de passe doit contenir au moins 6 caractères';
      case 'auth/too-many-requests':
        return 'Trop de tentatives. Réessayez plus tard';
      default:
        return 'Erreur d\'authentification';
    }
  }

  private getRandomColor(): string {
    const colors = [
      '#FF0000', // Rouge
      '#0000FF', // Bleu
      '#00FF00', // Vert
      '#FFFF00', // Jaune
      '#FFA500', // Orange
      '#800080', // Violet
      '#C0C0C0', // Argent
      '#000000', // Noir
      '#FFFFFF'  // Blanc
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  private getRandomPosition(): { x: number; y: number } {
    return {
      x: Math.floor(Math.random() * 600) + 50,
      y: Math.floor(Math.random() * 400) + 50
    };
  }

  testFirebaseConnection(): void {
    console.log('=== Test Firebase ===');
    console.log('Firestore disponible:', !!this.firestore);
    console.log('Auth disponible:', !!this.auth);
    console.log('Utilisateur actuel:', this.auth.currentUser?.email || 'Non connecté');
    console.log('GodotService disponible:', !!this.godotService);
  }

  // ============ OBSERVABLES POUR TEMPS RÉEL ============
  getCurrentUserProfile(): Observable<UserProfile | null> {
    return new Observable(observer => {
      const unsubscribe = onAuthStateChanged(this.auth, async (user) => {
        if (user) {
          const profile = await this.getUserProfile(user.uid);
          observer.next(profile);
        } else {
          observer.next(null);
        }
      });
      return () => unsubscribe();
    });
  }

  // Observables temps réel pour les pannes
  getPannesRealtime(userId?: string): Observable<Panne[]> {
    return new Observable(observer => {
      const pannesCollection = collection(this.firestore, 'pannes');
      let q;
      
      if (userId) {
        q = query(
          pannesCollection, 
          where('userId', '==', userId),
          orderBy('createdAt', 'desc')
        );
      } else {
        q = query(pannesCollection, orderBy('createdAt', 'desc'));
      }

      const unsubscribe = onSnapshot(q, (snapshot) => {
        const pannes: Panne[] = [];
        snapshot.forEach(doc => {
          const data = doc.data();
          pannes.push({ 
            id: doc.id, 
            ...this.parsePanneData(data)
          });
        });
        observer.next(pannes);
      }, (error) => {
        observer.error(error);
      });

      return () => unsubscribe();
    });
  }

  // Observer une panne spécifique en temps réel
  getPanneRealtime(panneId: string): Observable<Panne | null> {
    return new Observable(observer => {
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      
      const unsubscribe = onSnapshot(panneDoc, (docSnap) => {
        if (docSnap.exists()) {
          const data = docSnap.data();
          observer.next({ 
            id: docSnap.id, 
            ...this.parsePanneData(data)
          });
        } else {
          observer.next(null);
        }
      }, (error) => {
        observer.error(error);
      });

      return () => unsubscribe();
    });
  }
}