import {
  registerPlugin
} from "./chunk-I6GMFT3Z.js";
import "./chunk-EGSMBJJY.js";

// node_modules/@capacitor/push-notifications/dist/esm/index.js
var PushNotifications = registerPlugin("PushNotifications", {});
export {
  PushNotifications
};
//# sourceMappingURL=@capacitor_push-notifications.js.map
