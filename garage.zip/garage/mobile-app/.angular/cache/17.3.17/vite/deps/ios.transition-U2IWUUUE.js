import {
  iosTransitionAnimation,
  shadow
} from "./chunk-OCVSURPA.js";
import "./chunk-ETHHOL5G.js";
import "./chunk-NGDOZIFP.js";
import "./chunk-R3LVCYXH.js";
import "./chunk-REPSWCQI.js";
import "./chunk-EGSMBJJY.js";
export {
  iosTransitionAnimation,
  shadow
};
//# sourceMappingURL=ios.transition-U2IWUUUE.js.map
