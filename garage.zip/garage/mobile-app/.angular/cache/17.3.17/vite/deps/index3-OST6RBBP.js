import {
  GESTURE_CONTROLLER,
  createGesture
} from "./chunk-SNNZNKXU.js";
import "./chunk-EGSMBJJY.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
//# sourceMappingURL=index3-OST6RBBP.js.map
