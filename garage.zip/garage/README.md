# 🚗 Garage Simulation - Projet S5

## Description
Simulation de garage avec application mobile, web et jeu HTML.

## Architecture
- **Backend**: Laravel 10 + MySQL + Firebase
- **Frontend Web**: Vue.js 3 + Vite
- **Mobile**: Ionic/React Native (à venir)
- **Jeu**: HTML/Godot

## Prérequis
- Docker
- Docker Compose
- Git

## Installation

### 1. Cloner le projet
```bash
git clone <votre-repo>
cd garage-simulation