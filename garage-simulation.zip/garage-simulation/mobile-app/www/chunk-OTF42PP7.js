import{a}from"./chunk-6SYM2GBX.js";import"./chunk-JHI3MBHO.js";export{a as startFocusVisible};
