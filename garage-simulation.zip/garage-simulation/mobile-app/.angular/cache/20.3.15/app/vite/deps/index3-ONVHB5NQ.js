import {
  GESTURE_CONTROLLER,
  createGesture
} from "./chunk-KPULKOZU.js";
import "./chunk-EGSMBJJY.js";
export {
  GESTURE_CONTROLLER,
  createGesture
};
