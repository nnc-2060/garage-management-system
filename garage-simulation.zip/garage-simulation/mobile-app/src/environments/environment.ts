// src/environments/environment.ts
export const environment = {
  production: false,
  firebase: {
    apiKey: "AIzaSyAx2UWxLPwQMQJUSp3lp89QPubGBTcvkQQ",
    authDomain: "garagesimulator-17587.firebaseapp.com",
    projectId: "garagesimulator-17587",
    storageBucket: "garagesimulator-17587.appspot.com", // ← .appspot.com ici
    messagingSenderId: "902754509094",
    appId: "1:902754509094:web:dd3933418cd039c13021e7",
    measurementId: "G-EK3G9FW0SG"
  }
};