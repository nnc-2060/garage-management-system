export interface UserProfile {
  id?: string;
  uid: string;
  email: string;
  displayName: string;
  phone?: string;
  address?: string;
  createdAt: any; // Firestore Timestamp
  role: 'client' | 'technician' | 'admin';
  isActive: boolean;
  avatarUrl?: string;
  specialization?: string; // Pour les techniciens
  experienceYears?: number; // Pour les techniciens
}