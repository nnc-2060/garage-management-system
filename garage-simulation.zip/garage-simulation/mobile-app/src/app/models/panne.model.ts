export interface Panne {
  id?: string;
  description: string;
  timestamp: Date;
  status: 'en_attente' | 'en_cours' | 'terminée' | 'annulée';
  clientName: string;
  carModel: string;
  carYear?: number;
  carLicensePlate?: string;
  totalPrice: number;
  userId: string;
  userEmail: string;
  technicianId?: string;
  technicianName?: string;
  createdAt: any; // Firestore Timestamp
  updatedAt: any; // Firestore Timestamp
  startDate?: any; // Firestore Timestamp
  endDate?: any; // Firestore Timestamp
  estimatedTime?: number; // en heures
  parts?: Array<{
    name: string;
    quantity: number;
    unitPrice: number;
  }>;
  laborCost: number;
  partsCost: number;
  notes?: string;
  priority?: 'low' | 'medium' | 'high';
  
  // ============ NOUVEAUX CHAMPS POUR GODOT ============
  godotStatus?: 'waiting' | 'assigned' | 'in_progress' | 'completed' | 'paid';
  godotSlot?: 1 | 2 | null; // Slot dans le jeu (1 ou 2 maximum)
  godotRepairs?: {
    type: string;
    name: string;
    duration: number; // en secondes
    price: number;
    status: 'pending' | 'in_progress' | 'completed';
    progress: number; // 0 à 100
    startTime?: any; // Firestore Timestamp
    endTime?: any; // Firestore Timestamp
  }[];
  godotPosition?: {
    x: number; // Position X dans Godot
    y: number; // Position Y dans Godot
  };
  godotCarColor?: string; // Couleur hexadécimale (#FF0000)
  godotCarSprite?: string; // Nom du sprite dans Godot
  godotMechanicId?: string; // ID du mécanicien dans Godot
  godotCommandId?: string; // ID de la commande envoyée à Godot
  godotLastUpdate?: any; // Firestore Timestamp
}

// Interface pour les réparations Godot
export interface GodotRepair {
  type: 'frein' | 'vidange' | 'filtre' | 'batterie' | 'amortisseurs' | 'embrayage' | 'pneus' | 'refroidissement' | 'general';
  name: string;
  duration: number;
  price: number;
  status: 'pending' | 'in_progress' | 'completed';
  progress: number;
  startTime?: any;
  endTime?: any;
}

// Interface pour les commandes Godot
export interface GodotCommand {
  id?: string;
  type: 'NEW_PANNE' | 'REPAIR_START' | 'REPAIR_PROGRESS' | 'REPAIR_COMPLETE' | 'CAR_MOVE' | 'PAYMENT';
  panneId: string;
  data: any;
  timestamp: any;
  source: 'ionic_app' | 'godot_game';
  status: 'pending' | 'processing' | 'completed' | 'failed';
  processedBy?: string;
  processedAt?: any;
}