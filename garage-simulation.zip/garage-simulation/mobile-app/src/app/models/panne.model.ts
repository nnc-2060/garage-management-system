export interface Panne {
  id?: string;
  description: string;
  timestamp: Date;
  status: 'en_attente' | 'en_cours' | 'terminée' | 'annulée';
  clientName: string;
  carModel: string;
  carYear?: number;
  carLicensePlate?: string;
  totalPrice: number;
  userId: string;
  userEmail: string;
  technicianId?: string;
  technicianName?: string;
  createdAt: any; // Firestore Timestamp
  updatedAt: any; // Firestore Timestamp
  startDate?: any; // Firestore Timestamp
  endDate?: any; // Firestore Timestamp
  estimatedTime?: number; // en heures
  parts?: Array<{
    name: string;
    quantity: number;
    unitPrice: number;
  }>;
  laborCost: number;
  partsCost: number;
  notes?: string;
  priority?: 'low' | 'medium' | 'high';
}