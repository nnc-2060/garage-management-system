import { Component, OnInit, inject, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { User } from '@angular/fire/auth';
import { Subscription } from 'rxjs';
import { 
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonInput,
  IonButton,
  IonLabel,
  IonItem,
  IonList,
  IonCard,
  IonCardContent,
  IonIcon,
  IonCardHeader,
  IonCardTitle,
  IonText,
  IonButtons,
  IonGrid,
  IonRow,
  IonCol,
  IonTextarea,
  IonSelect,
  IonSelectOption,
  IonSpinner  
} from '@ionic/angular/standalone';
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { FirebaseService } from '../services/firebase.service';
import { Panne } from '../models/panne.model';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonInput,
    IonButton,
    IonLabel,
    IonItem,
    IonList,
    IonCard,
    IonCardContent,
    IonIcon,
    IonCardHeader,
    IonCardTitle,
    IonText,
    IonButtons,
    IonGrid,
    IonRow,
    IonCol,
    IonTextarea,
    IonSelect,
    IonSelectOption,
    IonSpinner  
  ]
})
export class HomePage implements OnInit, OnDestroy {
  panneDescription = '';
  clientName = '';
  carModel = '';
  carYear?: number;
  carLicensePlate = '';
  priority: 'low' | 'medium' | 'high' = 'medium';
  statusMessage = '';
  isLoggedIn = false;
  userEmail = '';
  userName = '';
  userStats: any = {};
  isLoading = false;
  
  private authSubscription!: Subscription;

  // Services
  private firebaseService = inject(FirebaseService);
  private router = inject(Router);

  ngOnInit() {
    this.checkAuth();
  }

  ngOnDestroy() {
    if (this.authSubscription) {
      this.authSubscription.unsubscribe();
    }
  }

  private checkAuth() {
    this.authSubscription = this.firebaseService.getCurrentUser().subscribe({
      next: async (user: User | null) => {
        this.isLoggedIn = !!user;
        this.userEmail = user?.email || '';
        
        if (user) {
          const profile = await this.firebaseService.getUserProfile(user.uid);
          this.userName = profile?.displayName || user.displayName || 'Utilisateur';
          
          if (this.userStats.terminées !== undefined) {
            this.userStats.completed = this.userStats.terminées;
          }
        }
      },
      error: (err) => {
        console.error('Erreur auth:', err);
        this.isLoggedIn = false;
      }
    });
  }

  async sendPanne() {
    if (!this.panneDescription.trim()) {
      this.showMessage('Veuillez décrire la panne');
      return;
    }

    if (!this.isLoggedIn) {
      this.showMessage('Veuillez vous connecter d\'abord');
      this.goToLogin();
      return;
    }

    this.isLoading = true;

    const panneData = {
      description: this.panneDescription,
      timestamp: new Date(),
      status: 'en_attente' as const,
      clientName: this.clientName || 'Anonyme',
      carModel: this.carModel || 'Non spécifié',
      carYear: this.carYear,
      carLicensePlate: this.carLicensePlate,
      priority: this.priority,
      totalPrice: 0,
      userId: '',
      userEmail: '',
      laborCost: 0,
      partsCost: 0
    };

    try {
      const result = await this.firebaseService.sendPanne(panneData);
      
      if (result.success) {
        this.showMessage(`✅ Panne #${result.id} signalée avec succès !`);
        this.notifyGodot(panneData);
        this.resetForm();
        
        this.userStats = await this.firebaseService.getStats();
      } else {
        this.showMessage(`❌ Erreur: ${result.error}`);
      }
    } catch (error: any) {
      this.showMessage(`Erreur: ${error.message}`);
    } finally {
      this.isLoading = false;
    }
  }

  private showMessage(message: string) {
    this.statusMessage = message;
    setTimeout(() => this.statusMessage = '', 5000);
  }

  private resetForm() {
    this.panneDescription = '';
    this.clientName = '';
    this.carModel = '';
    this.carYear = undefined;
    this.carLicensePlate = '';
    this.priority = 'medium';
  }

  private notifyGodot(panneData: any) {
    if (typeof window === 'undefined') return;
    
    localStorage.setItem('last_panne', JSON.stringify(panneData));
    console.log('📨 Données prêtes pour Godot:', panneData);
  }

  // Navigation
  goToLogin() {
    this.router.navigate(['/login']);
  }

  goToRegister() {
    this.router.navigate(['/register']);
  }

  goToRepairs() {
    this.router.navigate(['/repairs']);
  }

  goToProfile() {
    this.router.navigate(['/profile']);
  }

  async logout() {
    try {
      await this.firebaseService.logout();
      this.isLoggedIn = false;
      this.userEmail = '';
      this.userName = '';
      this.showMessage('Déconnexion réussie');
      this.router.navigate(['/login']);
    } catch (error) {
      this.showMessage('Erreur de déconnexion');
    }
  }

  testConnection() {
    this.firebaseService.testFirebaseConnection();
    this.showMessage('Test Firebase en cours...');
  }

  clearLocalData() {
    localStorage.removeItem('last_panne');
    
    if ('indexedDB' in window) {
      indexedDB.deleteDatabase('GarageDB');
    }
    
    this.showMessage('Données locales effacées');
  }

  goToAdminPannes() {
    this.router.navigate(['/admin-pannes']);
  }
}