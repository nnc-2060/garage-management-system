import { Injectable, inject } from '@angular/core';
import { 
  Firestore, 
  collection, 
  addDoc, 
  doc, 
  updateDoc,
  getDoc,
  Timestamp,
  where,
  query,
  onSnapshot,
  getDocs
} from '@angular/fire/firestore';
import { Auth } from '@angular/fire/auth';
import { Panne, GodotRepair } from '../models/panne.model';

@Injectable({
  providedIn: 'root'
})
export class GodotService {
  private firestore = inject(Firestore);
  private auth = inject(Auth);

  // Collection pour les commandes Godot
  private readonly GODOT_COMMANDS = 'godot_commands';
  
  // Types de réparations avec leurs spécifications
  private readonly REPAIR_SPECS = {
    'frein': { name: 'Changement des freins', duration: 300, price: 120 },
    'vidange': { name: 'Vidange moteur', duration: 180, price: 80 },
    'filtre': { name: 'Changement du filtre', duration: 150, price: 60 },
    'batterie': { name: 'Remplacement batterie', duration: 120, price: 150 },
    'amortisseurs': { name: 'Remplacement amortisseurs', duration: 600, price: 200 },
    'embrayage': { name: 'Réparation embrayage', duration: 900, price: 400 },
    'pneus': { name: 'Changement des pneus', duration: 240, price: 100 },
    'refroidissement': { name: 'Système de refroidissement', duration: 300, price: 180 },
    'general': { name: 'Diagnostic et réparation', duration: 300, price: 100 }
  };

  /**
   * Envoyer une panne à Godot
   */
  async sendPanneToGodot(panne: Panne): Promise<{success: boolean, commandId?: string, error?: string}> {
    try {
      const user = this.auth.currentUser;
      if (!user) throw new Error('Non connecté');

      if (!panne.id) throw new Error('ID de panne manquant');

      // 1. Extraire les réparations depuis la description
      const repairs = this.extractRepairsFromDescription(panne.description || '');
      
      // 2. Calculer le prix total pour Godot
      const totalGodotPrice = repairs.reduce((sum, repair) => sum + repair.price, 0);
      
      // 3. Préparer la commande pour Godot
      const godotCommand = {
        type: 'NEW_PANNE',
        panneId: panne.id,
        data: {
          // Info client
          client: {
            name: panne.clientName || 'Client',
            email: panne.userEmail || user.email
          },
          
          // Info voiture
          car: {
            model: panne.carModel || 'Inconnu',
            year: panne.carYear || 2020,
            licensePlate: panne.carLicensePlate || 'NC',
            color: panne.godotCarColor || this.getRandomColor(),
            position: panne.godotPosition || this.getRandomPosition()
          },
          
          // Réparations
          repairs: repairs,
          
          // Prix
          estimatedPrice: totalGodotPrice,
          estimatedTime: repairs.reduce((sum, repair) => sum + repair.duration, 0),
          
          // Métadonnées
          priority: panne.priority || 'medium',
          description: panne.description || ''
        },
        timestamp: Timestamp.now(),
        source: 'ionic_app',
        status: 'pending'
      };

      // 4. Envoyer la commande à Firestore
      const commandsCollection = collection(this.firestore, this.GODOT_COMMANDS);
      const docRef = await addDoc(commandsCollection, godotCommand);

      console.log('🚗 Commande Godot créée:', docRef.id);
      
      return { success: true, commandId: docRef.id };

    } catch (error: any) {
      console.error('❌ Erreur envoi à Godot:', error);
      return { success: false, error: error.message };
    }
  }

  /**
   * Extraire les réparations depuis la description
   */
  private extractRepairsFromDescription(description: string): GodotRepair[] {
    const descLower = description.toLowerCase();
    const repairs: GodotRepair[] = [];
    const foundTypes = new Set<string>();

    // Chercher chaque type de réparation
    for (const [type, spec] of Object.entries(this.REPAIR_SPECS)) {
      if (descLower.includes(type)) {
        foundTypes.add(type);
        repairs.push({
          type: type as GodotRepair['type'],
          name: spec.name,
          duration: spec.duration,
          price: spec.price,
          status: 'pending',
          progress: 0
        });
      }
    }

    // Si aucune réparation spécifique, ajouter une réparation générale
    if (repairs.length === 0) {
      repairs.push({
        type: 'general',
        name: this.REPAIR_SPECS.general.name,
        duration: this.REPAIR_SPECS.general.duration,
        price: this.REPAIR_SPECS.general.price,
        status: 'pending',
        progress: 0
      });
    }

    return repairs;
  }

  /**
   * Écouter les réponses de Godot pour une panne spécifique
   */
  listenToGodotResponses(panneId: string, callback: (response: any) => void) {
    const commandsCollection = collection(this.firestore, this.GODOT_COMMANDS);
    
    const q = query(
      commandsCollection,
      where('panneId', '==', panneId),
      where('source', '==', 'godot_game')
    );

    return onSnapshot(q, (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const response = change.doc.data();
          console.log('🔄 Réponse Godot reçue:', response['type'] || 'UNKNOWN');
          callback(response);
        }
      });
    }, (error) => {
      console.error('❌ Erreur écoute Godot:', error);
    });
  }

  /**
   * Écouter toutes les réponses de Godot (pour debug)
   */
  listenToAllGodotResponses(callback: (response: any) => void) {
    const commandsCollection = collection(this.firestore, this.GODOT_COMMANDS);
    
    const q = query(
      commandsCollection,
      where('source', '==', 'godot_game'),
      where('timestamp', '>', Timestamp.fromDate(new Date(Date.now() - 300000))) // 5 minutes
    );

    return onSnapshot(q, (snapshot) => {
      snapshot.docChanges().forEach((change) => {
        if (change.type === 'added') {
          const response = change.doc.data();
          console.log('🔄 Réponse Godot reçue:', response['type'] || 'UNKNOWN');
          callback(response);
        }
      });
    }, (error) => {
      console.error('❌ Erreur écoute globale Godot:', error);
    });
  }

  /**
   * Envoyer une action à Godot
   */
  async sendActionToGodot(type: string, panneId: string, data?: any): Promise<boolean> {
    try {
      if (!panneId) throw new Error('ID de panne requis');

      const command = {
        type: type,
        panneId: panneId,
        data: data || {},
        timestamp: Timestamp.now(),
        source: 'ionic_app',
        status: 'pending'
      };

      const commandsCollection = collection(this.firestore, this.GODOT_COMMANDS);
      await addDoc(commandsCollection, command);

      console.log(`⚡ Action envoyée à Godot: ${type}`);
      return true;
    } catch (error) {
      console.error('❌ Erreur envoi action:', error);
      return false;
    }
  }

  /**
   * Actions rapides pour le jeu
   */
  async sendQuickAction(panneId: string, action: 'horn' | 'lights' | 'test'): Promise<boolean> {
    const actions = {
      horn: { sound: 'horn', duration: 2 },
      lights: { state: 'on', color: '#FFFF00' },
      test: { message: 'Test depuis Ionic' }
    };

    return this.sendActionToGodot(action.toUpperCase(), panneId, actions[action]);
  }

  /**
   * Vérifier si Godot est actif
   */
  async checkGodotStatus(): Promise<boolean> {
    try {
      const commandsCollection = collection(this.firestore, this.GODOT_COMMANDS);
      const q = query(
        commandsCollection,
        where('source', '==', 'godot_game'),
        where('timestamp', '>', Timestamp.fromDate(new Date(Date.now() - 30000))) // 30 secondes
      );

      const snapshot = await getDocs(q);
      const isActive = !snapshot.empty;
      console.log('🔍 Godot actif?', isActive);
      return isActive;
    } catch (error) {
      console.error('❌ Erreur vérification Godot:', error);
      return false;
    }
  }

  /**
   * Obtenir le statut Godot d'une panne
   */
  async getPanneGodotStatus(panneId: string): Promise<any> {
    try {
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      const docSnap = await getDoc(panneDoc);
      
      if (docSnap.exists()) {
        const data = docSnap.data();
        return {
          godotStatus: data['godotStatus'],
          godotSlot: data['godotSlot'],
          godotRepairs: data['godotRepairs'],
          godotPosition: data['godotPosition'],
          godotCarColor: data['godotCarColor']
        };
      }
      return null;
    } catch (error) {
      console.error('❌ Erreur récupération statut Godot:', error);
      return null;
    }
  }

  /**
   * Générer une couleur aléatoire
   */
  private getRandomColor(): string {
    const colors = [
      '#FF0000', // Rouge
      '#0000FF', // Bleu
      '#00FF00', // Vert
      '#FFFF00', // Jaune
      '#FFA500', // Orange
      '#800080', // Violet
      '#C0C0C0', // Argent
      '#000000', // Noir
      '#FFFFFF'  // Blanc
    ];
    return colors[Math.floor(Math.random() * colors.length)];
  }

  /**
   * Générer une position aléatoire
   */
  private getRandomPosition(): { x: number; y: number } {
    return {
      x: Math.floor(Math.random() * 600) + 50,
      y: Math.floor(Math.random() * 400) + 50
    };
  }

  /**
   * Forcer le traitement d'une commande par Godot
   */
  async forceGodotProcess(panneId: string): Promise<boolean> {
    try {
      // Récupérer la panne
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      const docSnap = await getDoc(panneDoc);
      
      if (!docSnap.exists()) {
        console.error('❌ Panne non trouvée:', panneId);
        return false;
      }

      const panne = { id: panneId, ...docSnap.data() } as Panne;
      
      // Renvoyer à Godot
      const result = await this.sendPanneToGodot(panne);
      
      if (result.success) {
        console.log('🔄 Panne renvoyée à Godot:', panneId);
      }
      
      return result.success;
    } catch (error) {
      console.error('❌ Erreur forçage Godot:', error);
      return false;
    }
  }
}