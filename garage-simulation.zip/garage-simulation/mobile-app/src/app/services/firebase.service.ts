import { Injectable, inject } from '@angular/core';
import { Observable, from, map } from 'rxjs';
import { 
  Firestore, 
  collection, 
  addDoc, 
  doc, 
  setDoc,
  updateDoc,
  deleteDoc,
  getDoc,
  getDocs,
  query,
  where,
  orderBy,
  Timestamp,
  DocumentData
} from '@angular/fire/firestore';
import { 
  Auth, 
  authState, 
  signOut,
  signInWithEmailAndPassword,
  createUserWithEmailAndPassword,
  updateProfile,
  sendPasswordResetEmail,
  User,
  onAuthStateChanged
} from '@angular/fire/auth';
import { Panne } from '../models/panne.model';
import { UserProfile } from '../models/userProfile.model';

@Injectable({
  providedIn: 'root'
})
export class FirebaseService {
  private firestore = inject(Firestore);
  private auth = inject(Auth);

  // ============ AUTHENTIFICATION ============
  getCurrentUser(): Observable<User | null> {
    return authState(this.auth);
  }

  async login(email: string, password: string): Promise<{success: boolean, error?: string}> {
    try {
      await signInWithEmailAndPassword(this.auth, email, password);
      return { success: true };
    } catch (error: any) {
      console.error('Erreur login:', error);
      return { success: false, error: this.getAuthErrorMessage(error) };
    }
  }

  async register(email: string, password: string, fullName?: string, phone?: string): Promise<{success: boolean, error?: string}> {
    try {
      const userCredential = await createUserWithEmailAndPassword(this.auth, email, password);
      
      if (fullName && userCredential.user) {
        await updateProfile(userCredential.user, { displayName: fullName });
      }
      
      await this.createUserProfile(userCredential.user, fullName, phone);
      return { success: true };
    } catch (error: any) {
      console.error('Erreur register:', error);
      return { success: false, error: this.getAuthErrorMessage(error) };
    }
  }

  async logout(): Promise<void> {
    try {
      await signOut(this.auth);
    } catch (error) {
      console.error('Erreur de déconnexion:', error);
      throw error;
    }
  }

  async resetPassword(email: string): Promise<{success: boolean, error?: string}> {
    try {
      await sendPasswordResetEmail(this.auth, email);
      return { success: true };
    } catch (error: any) {
      console.error('Erreur reset password:', error);
      return { success: false, error: this.getAuthErrorMessage(error) };
    }
  }

  // ============ GESTION DES UTILISATEURS ============
  private async createUserProfile(user: User, fullName?: string, phone?: string): Promise<void> {
    try {
      const userProfile: UserProfile = {
        uid: user.uid,
        email: user.email || '',
        displayName: fullName || user.displayName || '',
        phone: phone || '',
        address: '',
        createdAt: Timestamp.now(),
        role: 'client',
        isActive: true
      };

      const userDoc = doc(this.firestore, `users/${user.uid}`);
      await setDoc(userDoc, userProfile);
      console.log('✅ Profil utilisateur créé');
    } catch (error) {
      console.error('❌ Erreur création profil:', error);
    }
  }

  async getUserProfile(uid: string): Promise<UserProfile | null> {
    try {
      const userDoc = doc(this.firestore, `users/${uid}`);
      const docSnap = await getDoc(userDoc);
      
      if (docSnap.exists()) {
        return { id: docSnap.id, ...docSnap.data() } as UserProfile;
      }
      return null;
    } catch (error) {
      console.error('Erreur récupération profil:', error);
      return null;
    }
  }

  async updateUserProfile(uid: string, data: Partial<UserProfile>): Promise<boolean> {
    try {
      const userDoc = doc(this.firestore, `users/${uid}`);
      await updateDoc(userDoc, {
        ...data,
        updatedAt: Timestamp.now()
      });
      return true;
    } catch (error) {
      console.error('Erreur mise à jour profil:', error);
      return false;
    }
  }

  // ============ GESTION DES PANNES ============
  async sendPanne(panneData: Omit<Panne, 'id' | 'createdAt' | 'updatedAt'>): Promise<{success: boolean, id?: string, error?: string}> {
    try {
      const user = this.auth.currentUser;
      if (!user) throw new Error('Utilisateur non connecté');

      const panneToSave = {
        ...panneData,
        userId: user.uid,
        userEmail: user.email,
        status: 'en_attente',
        timestamp: Timestamp.fromDate(new Date(panneData.timestamp)),
        createdAt: Timestamp.now(),
        updatedAt: Timestamp.now(),
        technicianId: '',
        technicianName: '',
        startDate: null,
        endDate: null,
        estimatedTime: 0,
        parts: [],
        laborCost: 0,
        partsCost: 0,
        notes: '',
        priority: 'medium'
      };

      const pannesCollection = collection(this.firestore, 'pannes');
      const docRef = await addDoc(pannesCollection, panneToSave);

      console.log('✅ Panne sauvegardée avec ID:', docRef.id);
      return { success: true, id: docRef.id };
    } catch (error: any) {
      console.error('❌ Erreur sauvegarde panne:', error);
      return { success: false, error: error.message };
    }
  }

  async getPannesByUser(userId: string): Promise<Panne[]> {
    try {
      const pannesCollection = collection(this.firestore, 'pannes');
      const q = query(
        pannesCollection, 
        where('userId', '==', userId),
        orderBy('createdAt', 'desc')
      );
      
      const querySnapshot = await getDocs(q);
      const pannes: Panne[] = [];
      
      querySnapshot.forEach(doc => {
        const data = doc.data();
        pannes.push({ 
          id: doc.id, 
          ...data,
          timestamp: data['timestamp']?.toDate() || new Date(),
          createdAt: data['createdAt']?.toDate() || new Date(),
          updatedAt: data['updatedAt']?.toDate() || new Date()
        } as Panne);
      });
      
      return pannes;
    } catch (error) {
      console.error('Erreur récupération pannes:', error);
      return [];
    }
  }

  async getAllPannes(): Promise<Panne[]> {
    try {
      const pannesCollection = collection(this.firestore, 'pannes');
      const q = query(pannesCollection, orderBy('createdAt', 'desc'));
      
      const querySnapshot = await getDocs(q);
      const pannes: Panne[] = [];
      
      querySnapshot.forEach(doc => {
        const data = doc.data();
        pannes.push({ 
          id: doc.id, 
          ...data,
          timestamp: data['timestamp']?.toDate() || new Date(),
          createdAt: data['createdAt']?.toDate() || new Date(),
          updatedAt: data['updatedAt']?.toDate() || new Date()
        } as Panne);
      });
      
      return pannes;
    } catch (error) {
      console.error('Erreur récupération toutes pannes:', error);
      return [];
    }
  }

  async updatePanneStatus(panneId: string, status: string, technicianId?: string, technicianName?: string): Promise<boolean> {
    try {
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      const updateData: any = { 
        status, 
        updatedAt: Timestamp.now() 
      };
      
      if (technicianId) {
        updateData.technicianId = technicianId;
      }
      if (technicianName) {
        updateData.technicianName = technicianName;
      }
      
      await updateDoc(panneDoc, updateData);
      return true;
    } catch (error) {
      console.error('Erreur mise à jour statut:', error);
      return false;
    }
  }

  async updatePanne(panneId: string, data: Partial<Panne>): Promise<boolean> {
    try {
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      await updateDoc(panneDoc, {
        ...data,
        updatedAt: Timestamp.now()
      });
      return true;
    } catch (error) {
      console.error('Erreur mise à jour panne:', error);
      return false;
    }
  }

  async deletePanne(panneId: string): Promise<boolean> {
    try {
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      await deleteDoc(panneDoc);
      return true;
    } catch (error) {
      console.error('Erreur suppression panne:', error);
      return false;
    }
  }

  async getPanneById(panneId: string): Promise<Panne | null> {
    try {
      const panneDoc = doc(this.firestore, `pannes/${panneId}`);
      const docSnap = await getDoc(panneDoc);
      
      if (docSnap.exists()) {
        const data = docSnap.data();
        return { 
          id: docSnap.id, 
          ...data,
          timestamp: data['timestamp']?.toDate() || new Date(),
          createdAt: data['createdAt']?.toDate() || new Date(),
          updatedAt: data['updatedAt']?.toDate() || new Date()
        } as Panne;
      }
      return null;
    } catch (error) {
      console.error('Erreur récupération panne:', error);
      return null;
    }
  }

  // ============ STATISTIQUES ============
  async getStats(userId?: string): Promise<any> {
    try {
      const pannesCollection = collection(this.firestore, 'pannes');
      let q;
      
      if (userId) {
        q = query(pannesCollection, where('userId', '==', userId));
      } else {
        q = query(pannesCollection);
      }
      
      const querySnapshot = await getDocs(q);
      const stats = {
        total: 0,
        en_attente: 0,
        en_cours: 0,
        completed: 0,
        annulées: 0,
        totalRevenue: 0
      };
      
      querySnapshot.forEach(doc => {
        const data = doc.data();
        stats.total++;
        
        const status = data['status'];
        if (status && stats.hasOwnProperty(status)) {
          stats[status as keyof typeof stats] = (stats[status as keyof typeof stats] || 0) + 1;
        }
        
        if (data['totalPrice']) {
          stats.totalRevenue += data['totalPrice'];
        }
      });
      
      return stats;
    } catch (error) {
      console.error('Erreur calcul stats:', error);
      return {};
    }
  }

  // ============ UTILITAIRES ============
  private getAuthErrorMessage(error: any): string {
    const errorCode = error.code;
    
    switch(errorCode) {
      case 'auth/user-not-found':
        return 'Utilisateur non trouvé';
      case 'auth/wrong-password':
        return 'Mot de passe incorrect';
      case 'auth/invalid-email':
        return 'Email invalide';
      case 'auth/email-already-in-use':
        return 'Cet email est déjà utilisé';
      case 'auth/weak-password':
        return 'Le mot de passe doit contenir au moins 6 caractères';
      case 'auth/too-many-requests':
        return 'Trop de tentatives. Réessayez plus tard';
      default:
        return 'Erreur d\'authentification';
    }
  }

  testFirebaseConnection(): void {
    console.log('=== Test Firebase ===');
    console.log('Firestore disponible:', !!this.firestore);
    console.log('Auth disponible:', !!this.auth);
    console.log('Utilisateur actuel:', this.auth.currentUser?.email || 'Non connecté');
  }

  // ============ OBSERVABLES POUR TEMPS RÉEL ============
  getCurrentUserProfile(): Observable<UserProfile | null> {
    return new Observable(observer => {
      const unsubscribe = onAuthStateChanged(this.auth, async (user) => {
        if (user) {
          const profile = await this.getUserProfile(user.uid);
          observer.next(profile);
        } else {
          observer.next(null);
        }
      });
      return () => unsubscribe();
    });
  }
}