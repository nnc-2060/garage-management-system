import { Component, OnInit, inject } from '@angular/core';
import { CommonModule } from '@angular/common';
import { FormsModule } from '@angular/forms';
import { 
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonList,
  IonItem,
  IonLabel,
  IonBadge,
  IonButton,
  IonIcon,
  IonCard,
  IonCardContent,
  IonSelect,
  IonSelectOption,
  IonButtons,
  IonBackButton,
  IonSpinner,
  IonModal,
  IonInput,
  // AJOUTEZ CES IMPORTS MANQUANTS
  IonCardHeader,
  IonCardTitle,
  IonCardSubtitle,
  IonGrid,
  IonRow,
  IonCol
} from '@ionic/angular/standalone';
import { FirebaseService } from '../../services/firebase.service';
import { Panne } from '../../models/panne.model';

@Component({
  selector: 'app-admin-pannes',
  templateUrl: './adminPannes.page.html',
  styleUrls: ['./adminPannes.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonList,
    IonItem,
    IonLabel,
    IonBadge,
    IonButton,
    IonIcon,
    IonCard,
    IonCardContent,
    IonSelect,
    IonSelectOption,
    IonButtons,
    IonBackButton,
    IonSpinner,
    IonModal,
    IonInput,
    // AJOUTEZ CES IMPORTS ICI
    IonCardHeader,
    IonCardTitle,
    IonCardSubtitle,
    IonGrid,
    IonRow,
    IonCol
  ]
})
export class AdminPannesPage implements OnInit {
  allPannes: Panne[] = [];
  filteredPannes: Panne[] = [];
  isLoading = true;
  statusFilter = 'all';
  selectedPanne: Panne | null = null;
  isModalOpen = false;
  newStatus = '';
  technicianName = '';
  
  // Statistiques calculées
  stats = {
    total: 0,
    enAttente: 0,
    enCours: 0,
    terminees: 0,
    annulees: 0
  };
  
  private firebaseService = inject(FirebaseService);

  async ngOnInit() {
    await this.loadAllPannes();
  }

  async loadAllPannes() {
    this.isLoading = true;
    this.allPannes = await this.firebaseService.getAllPannes();
    this.calculateStats();
    this.filterByStatus();
    this.isLoading = false;
  }

  calculateStats() {
    this.stats.total = this.allPannes.length;
    this.stats.enAttente = this.allPannes.filter(p => p.status === 'en_attente').length;
    this.stats.enCours = this.allPannes.filter(p => p.status === 'en_cours').length;
    this.stats.terminees = this.allPannes.filter(p => p.status === 'terminée').length;
    this.stats.annulees = this.allPannes.filter(p => p.status === 'annulée').length;
  }

  filterByStatus() {
    if (this.statusFilter === 'all') {
      this.filteredPannes = [...this.allPannes];
    } else {
      this.filteredPannes = this.allPannes.filter(p => p.status === this.statusFilter);
    }
  }

  openStatusModal(panne: Panne) {
    this.selectedPanne = panne;
    this.newStatus = panne.status;
    this.isModalOpen = true;
  }

  async updateStatus() {
    if (!this.selectedPanne || !this.selectedPanne.id) return;
    
    const success = await this.firebaseService.updatePanneStatus(
      this.selectedPanne.id, 
      this.newStatus,
      'tech-id', // À remplacer avec l'ID du technicien connecté
      this.technicianName
    );
    
    if (success) {
      await this.loadAllPannes();
      this.isModalOpen = false;
      this.selectedPanne = null;
      this.technicianName = '';
    }
  }

  formatDate(timestamp: any): string {
    if (!timestamp) return 'N/A';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleDateString('fr-FR') + ' ' + date.toLocaleTimeString('fr-FR', { hour: '2-digit', minute: '2-digit' });
  }

  getStatusColor(status: string): string {
    switch(status) {
      case 'terminée': return 'success';
      case 'en_cours': return 'warning';
      case 'en_attente': return 'medium';
      case 'annulée': return 'danger';
      default: return 'medium';
    }
  }

  getStatusText(status: string): string {
    switch(status) {
      case 'en_attente': return 'En attente';
      case 'en_cours': return 'En cours';
      case 'terminée': return 'Terminée';
      case 'annulée': return 'Annulée';
      default: return status;
    }
  }
}