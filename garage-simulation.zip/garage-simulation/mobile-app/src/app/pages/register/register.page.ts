import { Component, inject } from '@angular/core';
import { Router } from '@angular/router'; // RETIRER RouterLink
import { FormsModule } from '@angular/forms';
import { CommonModule } from '@angular/common';
import { 
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonInput,
  IonButton,
  IonLabel,
  IonItem,
  IonList,
  IonCard,
  IonCardContent,
  // IonIcon,  // RETIRER si non utilisé
  IonCardHeader,
  IonCardTitle,
  IonText,
  IonButtons,
  IonBackButton,
  IonSpinner
} from '@ionic/angular/standalone';
import { FirebaseService } from '../../services/firebase.service';

@Component({
  selector: 'app-register',
  templateUrl: './register.page.html',
  styleUrls: ['./register.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    FormsModule,
    // RETIRER RouterLink
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonInput,
    IonButton,
    IonLabel,
    IonItem,
    IonList,
    IonCard,
    IonCardContent,
    // IonIcon,  // RETIRER si non utilisé
    IonCardHeader,
    IonCardTitle,
    IonText,
    IonButtons,
    IonBackButton,
    IonSpinner
  ]
})
export class RegisterPage {
  email = '';
  password = '';
  confirmPassword = '';
  fullName = '';
  phone = '';
  errorMessage = '';
  isLoading = false;

  private firebaseService = inject(FirebaseService);
  private router = inject(Router);

  async register() {
    if (!this.email || !this.password || !this.confirmPassword) {
      this.errorMessage = 'Veuillez remplir tous les champs obligatoires';
      return;
    }

    if (this.password !== this.confirmPassword) {
      this.errorMessage = 'Les mots de passe ne correspondent pas';
      return;
    }

    if (this.password.length < 6) {
      this.errorMessage = 'Le mot de passe doit contenir au moins 6 caractères';
      return;
    }

    this.isLoading = true;
    this.errorMessage = '';

    const result = await this.firebaseService.register(this.email, this.password, this.fullName, this.phone);
    
    if (result.success) {
      this.router.navigate(['/login']);
    } else {
      this.errorMessage = result.error || 'Erreur d\'inscription';
    }
    
    this.isLoading = false;
  }

  goToLogin() {
    this.router.navigate(['/login']);
  }

  goToHome() {
    this.router.navigate(['/']);
  }
}