import { Component, OnInit, inject, OnDestroy } from '@angular/core';
import { Router } from '@angular/router';
import { CommonModule } from '@angular/common';
import { Subscription } from 'rxjs';
import { 
  IonContent,
  IonHeader,
  IonTitle,
  IonToolbar,
  IonButton,
  IonLabel,
  IonItem,
  IonList,
  IonCard,
  IonCardContent,
  IonIcon,
  IonCardHeader,
  IonCardTitle,
  // IonText,  // RETIRER si non utilisé
  IonButtons,
  IonBackButton,
  IonBadge,
  IonChip,
  IonSpinner  // AJOUTER si utilisé
} from '@ionic/angular/standalone';
import { FirebaseService } from '../../services/firebase.service';
import { Panne } from '../../models/panne.model';

@Component({
  selector: 'app-repairs',
  templateUrl: './repairs.page.html',
  styleUrls: ['./repairs.page.scss'],
  standalone: true,
  imports: [
    CommonModule,
    IonContent,
    IonHeader,
    IonTitle,
    IonToolbar,
    IonButton,
    IonLabel,
    IonItem,
    IonList,
    IonCard,
    IonCardContent,
    IonIcon,
    IonCardHeader,
    IonCardTitle,
    // IonText,  // RETIRER si non utilisé
    IonButtons,
    IonBackButton,
    IonBadge,
    IonChip,
    IonSpinner  // AJOUTER si utilisé
  ]
})
export class RepairsPage implements OnInit, OnDestroy {
  repairs: Panne[] = [];
  filteredRepairs: Panne[] = [];
  activeFilter: string = 'all';
  isLoading = true;
  
  totalRepairs: number = 0;
  completedRepairs: number = 0;
  inProgressRepairs: number = 0;
  totalSpent: number = 0;
  
  private authSubscription!: Subscription;
  private firebaseService = inject(FirebaseService);
  private router = inject(Router);

  async ngOnInit() {
    await this.loadRepairs();
  }

  ngOnDestroy() {
    if (this.authSubscription) {
      this.authSubscription.unsubscribe();
    }
  }

  async loadRepairs() {
    this.isLoading = true;
    
    this.authSubscription = this.firebaseService.getCurrentUser().subscribe({
      next: async (user) => {
        if (user) {
          this.repairs = await this.firebaseService.getPannesByUser(user.uid);
          this.calculateStats();
          this.filterRepairs('all');
        }
        this.isLoading = false;
      },
      error: (err) => {
        console.error('Erreur chargement réparations:', err);
        this.isLoading = false;
      }
    });
  }

  calculateStats() {
    this.totalRepairs = this.repairs.length;
    this.completedRepairs = this.repairs.filter(r => r.status === 'terminée').length;
    this.inProgressRepairs = this.repairs.filter(r => 
      r.status === 'en_attente' || r.status === 'en_cours'
    ).length;
    this.totalSpent = this.repairs.reduce((sum, r) => sum + r.totalPrice, 0);
  }

  filterRepairs(status: string) {
    this.activeFilter = status;
    
    if (status === 'all') {
      this.filteredRepairs = this.repairs;
    } else {
      this.filteredRepairs = this.repairs.filter(repair => repair.status === status);
    }
  }

  getStatusText(status: string): string {
    switch(status) {
      case 'en_attente': return 'En attente';
      case 'en_cours': return 'En cours';
      case 'terminée': return 'Terminée';
      case 'annulée': return 'Annulée';
      default: return status;
    }
  }

  getStatusColor(status: string): string {
    switch(status) {
      case 'terminée': return 'success';
      case 'en_cours': return 'warning';
      case 'en_attente': return 'medium';
      case 'annulée': return 'danger';
      default: return 'medium';
    }
  }

  formatDate(timestamp: any): string {
    if (!timestamp) return 'N/A';
    const date = timestamp.toDate ? timestamp.toDate() : new Date(timestamp);
    return date.toLocaleDateString('fr-FR');
  }

  viewRepairDetails(repair: Panne) {
    console.log('Détails réparation:', repair);
  }

  goToHome() {
    this.router.navigate(['/']);
  }

  addNewRepair() {
    this.router.navigate(['/']);
  }
}